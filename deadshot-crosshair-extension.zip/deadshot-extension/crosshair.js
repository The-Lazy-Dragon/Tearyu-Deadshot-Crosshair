(function () {
  'use strict';
  if (window.__ds_xhair_ext_v4) return;
  window.__ds_xhair_ext_v4 = true;

  // ─── SETTINGS ────────────────────────────────────────────────────────────────
  const KEY = 'ds_xhair_v4';
  const defaults = {
    masterShow:    true,
    color:         '#00ff88',
    outlineColor:  '#000000',
    showOutline:   true,
    showDot:       false,
    dotSize:       2,
    style:         'cross',
    showTop:       true, showBottom: true, showLeft: true, showRight: true,
    len:           12, thick: 2, gap: 4,
    opacity:       1.0,
    circleRadius:  14,
    showFPS:       true,
    showPing:      true,
    showKeys:      true,
    sidebarVisible: true,
    showPreview:   true,
    overlayColor:  '#00ff88',
    psychedelic:   false,
    psychoSpeed:   3,
  };

  let S = (() => {
    try { return Object.assign({}, defaults, JSON.parse(localStorage.getItem(KEY))); }
    catch (e) { return Object.assign({}, defaults); }
  })();
  function save() { localStorage.setItem(KEY, JSON.stringify(S)); }

  // ─── PSYCHEDELIC ENGINE ───────────────────────────────────────────────────────
  // Throttled to ~20fps via setInterval — no canvas redraw every frame,
  // only redraws crosshair canvas. Preview only redraws if its panel is open.
  let psychoHue = 0;
  let psychoInterval = null;
  let psychoLastDraw = 0;

  function hslToHex(h, s, l) {
    s /= 100; l /= 100;
    const k = n => (n + h / 30) % 12;
    const a = s * Math.min(l, 1 - l);
    const f = n => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    return '#' + [f(0), f(8), f(4)].map(x => Math.round(x * 255).toString(16).padStart(2, '0')).join('');
  }

  function psychoTick() {
    psychoHue = (psychoHue + S.psychoSpeed * 0.8) % 360;
    const col  = hslToHex(psychoHue, 100, 55);
    const col2 = hslToHex((psychoHue + 180) % 360, 100, 55);

    S.color        = col;
    S.outlineColor = col2;
    S.overlayColor = col;

    // Overlay color: just flip CSS var — no DOM repaint
    document.documentElement.style.setProperty('--ds-overlay-col', col);
    const fps  = document.getElementById('ds-fps-el');
    const ping = document.getElementById('ds-ping-el');
    if (fps)  fps.style.color = col;
    if (ping) ping.style.color = col;

    // Redraw main crosshair canvas
    if (S.masterShow) drawXH(ctx, 60, 60, S, 120);

    // Only redraw preview if the overlays panel is currently open (user is looking at it)
    if (S.showPreview && openPanel === 'overlays') redrawPreview();
  }

  function startPsycho() {
    if (psychoInterval) return;
    // 50ms = 20fps — smooth enough, won't murder the game
    psychoInterval = setInterval(psychoTick, 50);
  }

  function stopPsycho() {
    if (psychoInterval) { clearInterval(psychoInterval); psychoInterval = null; }
  }

  // ─── DRAW ENGINE ─────────────────────────────────────────────────────────────
  function drawXH(context, cx, cy, s, size) {
    context.clearRect(0, 0, size, size);
    context.globalAlpha = s.opacity;
    const g2 = s.gap, l = s.len, t = s.thick;
    const col = s.color, out = s.outlineColor;

    function applyOutline(fn) {
      if (s.showOutline) {
        context.strokeStyle = out;
        context.lineWidth = t + 2;
        context.lineCap = 'square';
        fn(); context.stroke();
      }
      context.strokeStyle = col;
      context.lineWidth = t;
      context.lineCap = 'square';
      fn(); context.stroke();
    }

    function dot() {
      if (s.showOutline) {
        context.fillStyle = out;
        context.beginPath(); context.arc(cx, cy, s.dotSize + 1, 0, Math.PI * 2); context.fill();
      }
      context.fillStyle = col;
      context.beginPath(); context.arc(cx, cy, s.dotSize, 0, Math.PI * 2); context.fill();
    }

    function crossArms() {
      if (s.showLeft)   applyOutline(() => { context.beginPath(); context.moveTo(cx-g2-l, cy); context.lineTo(cx-g2, cy); });
      if (s.showRight)  applyOutline(() => { context.beginPath(); context.moveTo(cx+g2, cy); context.lineTo(cx+g2+l, cy); });
      if (s.showTop)    applyOutline(() => { context.beginPath(); context.moveTo(cx, cy-g2-l); context.lineTo(cx, cy-g2); });
      if (s.showBottom) applyOutline(() => { context.beginPath(); context.moveTo(cx, cy+g2); context.lineTo(cx, cy+g2+l); });
    }

    function circle() {
      applyOutline(() => { context.beginPath(); context.arc(cx, cy, s.circleRadius, 0, Math.PI * 2); });
    }

    function diamond() {
      const r = l + g2;
      if (s.showOutline) {
        context.strokeStyle = out; context.lineWidth = t + 2; context.lineJoin = 'miter';
        context.beginPath(); context.moveTo(cx, cy-r); context.lineTo(cx+r, cy);
        context.lineTo(cx, cy+r); context.lineTo(cx-r, cy); context.closePath(); context.stroke();
      }
      context.strokeStyle = col; context.lineWidth = t; context.lineJoin = 'miter';
      context.beginPath(); context.moveTo(cx, cy-r); context.lineTo(cx+r, cy);
      context.lineTo(cx, cy+r); context.lineTo(cx-r, cy); context.closePath(); context.stroke();
    }

    function square() {
      const r = l + g2;
      if (s.showOutline) {
        context.strokeStyle = out; context.lineWidth = t + 2; context.lineJoin = 'miter';
        context.strokeRect(cx-r, cy-r, r*2, r*2);
      }
      context.strokeStyle = col; context.lineWidth = t; context.lineJoin = 'miter';
      context.strokeRect(cx-r, cy-r, r*2, r*2);
    }

    function diagArms() {
      const d = (g2+l)*Math.SQRT1_2, gd = g2*Math.SQRT1_2;
      applyOutline(() => { context.beginPath(); context.moveTo(cx-gd,cy-gd); context.lineTo(cx-d,cy-d); });
      applyOutline(() => { context.beginPath(); context.moveTo(cx+gd,cy-gd); context.lineTo(cx+d,cy-d); });
      applyOutline(() => { context.beginPath(); context.moveTo(cx+gd,cy+gd); context.lineTo(cx+d,cy+d); });
      applyOutline(() => { context.beginPath(); context.moveTo(cx-gd,cy+gd); context.lineTo(cx-d,cy+d); });
    }

    const st = s.style;
    if      (st==='cross')               { crossArms(); }
    else if (st==='cross_dot')           { crossArms(); dot(); }
    else if (st==='dot')                 { dot(); }
    else if (st==='circle')              { circle(); }
    else if (st==='circle_cross')        { circle(); crossArms(); }
    else if (st==='circle_cross_dot')    { circle(); crossArms(); dot(); }
    else if (st==='diamond')             { diamond(); }
    else if (st==='diamond_dot')         { diamond(); dot(); }
    else if (st==='diamond_cross')       { diamond(); crossArms(); }
    else if (st==='square')              { square(); }
    else if (st==='square_dot')          { square(); dot(); }
    else if (st==='square_cross_perp')   { square(); crossArms(); }
    else if (st==='square_cross_perp_dot'){ square(); crossArms(); dot(); }
    else if (st==='square_cross_diag')   { square(); diagArms(); }
    else if (st==='square_cross_diag_dot'){ square(); diagArms(); dot(); }

    context.globalAlpha = 1;
  }

  // ─── CROSSHAIR CANVAS ────────────────────────────────────────────────────────
  const cv = document.createElement('canvas');
  cv.width = cv.height = 120;
  Object.assign(cv.style, {
    position:'fixed', top:'50%', left:'50%',
    transform:'translate(-50%,-50%)',
    pointerEvents:'none', zIndex:'999998', imageRendering:'pixelated',
  });
  document.body.appendChild(cv);
  const ctx = cv.getContext('2d');

  // ─── PREVIEW BOX (draggable) ─────────────────────────────────────────────────
  const prevWrap = document.createElement('div');
  prevWrap.id = 'ds-preview-wrap';
  prevWrap.style.cssText = 'position:fixed;bottom:20px;right:20px;z-index:9999996;background:#111;border:1px solid #2a2a2a;border-radius:10px;width:120px;height:120px;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 20px rgba(0,0,0,.7);cursor:grab;user-select:none;';
  const prevLbl = document.createElement('div');
  prevLbl.textContent = 'PREVIEW';
  prevLbl.style.cssText = 'position:absolute;top:5px;left:50%;transform:translateX(-50%);font:700 9px Consolas,monospace;color:#333;letter-spacing:.08em;pointer-events:none;';
  const prevCv = document.createElement('canvas');
  prevCv.width = prevCv.height = 100;
  prevCv.style.pointerEvents = 'none';
  const pctx = prevCv.getContext('2d');
  prevWrap.appendChild(prevLbl);
  prevWrap.appendChild(prevCv);
  document.body.appendChild(prevWrap);

  // Make preview draggable
  (function() {
    let drag = false, ox = 0, oy = 0;
    prevWrap.addEventListener('mousedown', e => {
      drag = true;
      const r = prevWrap.getBoundingClientRect();
      ox = e.clientX - r.left; oy = e.clientY - r.top;
      prevWrap.style.cursor = 'grabbing';
      e.preventDefault();
    });
    document.addEventListener('mousemove', e => {
      if (!drag) return;
      prevWrap.style.left   = (e.clientX - ox) + 'px';
      prevWrap.style.top    = (e.clientY - oy) + 'px';
      prevWrap.style.right  = 'auto';
      prevWrap.style.bottom = 'auto';
    });
    document.addEventListener('mouseup', () => { drag = false; prevWrap.style.cursor = 'grab'; });
  })();

  function redrawPreview() {
    if (S.masterShow) {
      drawXH(pctx, 50, 50, S, 100);
    } else {
      pctx.clearRect(0, 0, 100, 100);
      pctx.fillStyle = '#ff4444';
      pctx.font = 'bold 10px Arial,sans-serif';
      pctx.textAlign = 'center';
      pctx.fillText('OFF', 50, 55);
    }
  }

  function redraw() {
    cv.style.display = S.masterShow ? 'block' : 'none';
    if (S.masterShow) drawXH(ctx, 60, 60, S, 120);
    if (S.showPreview) redrawPreview();
  }

  function updatePreviewVisibility() {
    prevWrap.style.display = S.showPreview ? 'flex' : 'none';
  }

  // ─── HUD OVERLAYS ────────────────────────────────────────────────────────────
  const overlayEl = document.createElement('div');
  overlayEl.id = 'ds-overlay-root';
  overlayEl.style.cssText = 'position:fixed!important;top:15px!important;left:15px!important;z-index:9999995!important;pointer-events:none!important;display:flex!important;flex-direction:column!important;gap:10px!important;user-select:none!important;';
  overlayEl.innerHTML = `
    <div id="ds-fps-el"  style="font-size:17px;font-weight:700;font-family:Consolas,monospace;text-shadow:1px 1px 0 #000,-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000;">FPS: --</div>
    <div id="ds-ping-el" style="font-size:17px;font-weight:700;font-family:Consolas,monospace;text-shadow:1px 1px 0 #000,-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000;">PING: --ms</div>
    <div id="ds-keys-el" style="display:flex;flex-direction:column;gap:4px;margin-top:6px;"></div>
  `;
  document.body.appendChild(overlayEl);

  const kbCSS = document.createElement('style');
  kbCSS.textContent = `
    .ds-kb{background:rgba(0,0,0,.6);border:2px solid var(--ds-overlay-col,#00ff88);color:var(--ds-overlay-col,#00ff88);border-radius:4px;min-width:33px;height:33px;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;padding:0 5px;transition:border-color .1s,color .1s;font-family:Consolas,monospace;}
    .ds-kb.active{background:var(--ds-overlay-col,#00ff88);color:#000;transform:scale(.93);box-shadow:0 0 8px var(--ds-overlay-col,#00ff88);}
  `;
  document.head.appendChild(kbCSS);

  document.getElementById('ds-keys-el').innerHTML = `
    <div style="display:flex;gap:4px;justify-content:center;"><div class="ds-kb" id="kb-Mouse0">LMB</div><div class="ds-kb" id="kb-KeyW">W</div><div class="ds-kb" id="kb-Mouse2">RMB</div></div>
    <div style="display:flex;gap:4px;"><div class="ds-kb" id="kb-KeyA">A</div><div class="ds-kb" id="kb-KeyS">S</div><div class="ds-kb" id="kb-KeyD">D</div></div>
    <div style="display:flex;gap:4px;"><div class="ds-kb" id="kb-ShiftLeft" style="min-width:50px">SHFT</div><div class="ds-kb" id="kb-Space" style="flex:1">SPC</div><div class="ds-kb" id="kb-KeyR">R</div><div class="ds-kb" id="kb-KeyF">F</div></div>
  `;

  function applyOverlayColor() {
    const c = S.overlayColor;
    document.documentElement.style.setProperty('--ds-overlay-col', c);
    const fps = document.getElementById('ds-fps-el');
    const ping = document.getElementById('ds-ping-el');
    if (fps)  fps.style.color  = c;
    if (ping) ping.style.color = c;
  }

  function applyKeyColor() {
    document.documentElement.style.setProperty('--ds-overlay-col', S.overlayColor);
  }

  // FPS counter
  let frames = 0, lastT = performance.now();
  (function fpsLoop() {
    frames++;
    const now = performance.now();
    if (now - lastT >= 1000) {
      const el = document.getElementById('ds-fps-el');
      if (el) el.textContent = 'FPS: ' + frames;
      frames = 0; lastT = now;
    }
    requestAnimationFrame(fpsLoop);
  })();

  // Ping
  setInterval(async () => {
    const el = document.getElementById('ds-ping-el');
    if (!el) return;
    const t = performance.now();
    try { await fetch(location.origin + '/?ping=' + Date.now(), { method: 'HEAD', cache: 'no-store' }); } catch (e) {}
    el.textContent = 'PING: ' + Math.round(performance.now() - t) + 'ms';
  }, 2000);

  // Key tracker
  const hk = (code, down) => {
    const el = document.getElementById('kb-' + code);
    if (el) el.classList.toggle('active', down);
  };
  window.addEventListener('keydown',   e => hk(e.code, true));
  window.addEventListener('keyup',     e => hk(e.code, false));
  window.addEventListener('mousedown', e => hk('Mouse' + e.button, true));
  window.addEventListener('mouseup',   e => hk('Mouse' + e.button, false));

  function updateOverlays() {
    const fps  = document.getElementById('ds-fps-el');
    const ping = document.getElementById('ds-ping-el');
    const keys = document.getElementById('ds-keys-el');
    if (fps)  fps.style.display  = S.showFPS  ? '' : 'none';
    if (ping) ping.style.display = S.showPing ? '' : 'none';
    if (keys) keys.style.display = S.showKeys ? '' : 'none';
    applyOverlayColor();
  }

  // ─── CSS ─────────────────────────────────────────────────────────────────────
  const mainCSS = document.createElement('style');
  mainCSS.textContent = `
    .ds-panel{display:none;position:fixed;top:50%;right:70px;transform:translateY(-50%);z-index:9999997;background:#181818;border:1px solid #2a2a2a;border-radius:12px;width:300px;max-height:82vh;overflow-y:auto;overflow-x:hidden;padding:18px 18px 14px;font-family:'Segoe UI',Arial,sans-serif;color:#e0e0e0;box-shadow:0 8px 32px rgba(0,0,0,.85);scrollbar-width:thin;scrollbar-color:#333 #111;}
    .ds-panel::-webkit-scrollbar{width:5px;}
    .ds-panel::-webkit-scrollbar-track{background:#111;}
    .ds-panel::-webkit-scrollbar-thumb{background:#333;border-radius:3px;}
    .ds-panel.open{display:block;}
    .ds-panel h2{margin:0 0 2px;font-size:14px;font-weight:700;color:#fff;letter-spacing:.05em;text-transform:uppercase;}
    .ds-hint{font-size:10px;color:#444;margin:0 0 14px;font-family:'Segoe UI',Arial,sans-serif;}
    .ds-section{font-size:9px;text-transform:uppercase;letter-spacing:.1em;color:#444;margin:14px 0 8px;border-top:1px solid #222;padding-top:8px;}
    .ds-row{display:flex;align-items:center;gap:8px;margin-bottom:9px;}
    .ds-row label{font-size:12px;color:#999;min-width:88px;font-family:'Segoe UI',Arial,sans-serif;}
    .ds-row input[type=range]{flex:1;accent-color:#00ff88;height:3px;cursor:pointer;}
    .ds-val{font-size:12px;font-weight:700;min-width:32px;text-align:right;color:#fff;font-family:Consolas,monospace;}
    .ds-row input[type=color]{width:32px;height:24px;border:none;border-radius:4px;cursor:pointer;padding:1px;background:none;}
    .ds-row input[type=text]{flex:1;background:#222;color:#eee;border:1px solid #2a2a2a;border-radius:5px;padding:4px 7px;font-size:12px;font-family:Consolas,monospace;outline:none;}
    .ds-row select{flex:1;background:#222;color:#eee;border:1px solid #2a2a2a;border-radius:5px;padding:5px 7px;font-size:12px;font-family:'Segoe UI',Arial,sans-serif;outline:none;}
    .ds-toggle{display:flex;align-items:center;gap:8px;margin-bottom:9px;cursor:pointer;}
    .ds-toggle label{font-size:12px;color:#999;flex:1;cursor:pointer;font-family:'Segoe UI',Arial,sans-serif;}
    .ds-toggle input[type=checkbox]{width:14px;height:14px;accent-color:#00ff88;cursor:pointer;}
    .ds-foot{display:flex;gap:8px;margin-top:14px;padding-top:12px;border-top:1px solid #222;}
    .ds-btn{flex:1;padding:8px 0;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;border:none;letter-spacing:.04em;font-family:'Segoe UI',Arial,sans-serif;}
    .ds-btn-save{background:#00ff88;color:#000;}
    .ds-btn-save:hover{background:#00cc6a;}
    .ds-btn-reset{background:#2a2a2a;color:#888;}
    .ds-btn-reset:hover{background:#333;color:#fff;}
    .ds-btn-psycho{background:linear-gradient(90deg,#ff0080,#ff8800,#ffff00,#00ff88,#00cfff,#8800ff,#ff0080);background-size:200% 100%;color:#000;animation:none;}
    .ds-btn-psycho.on{animation:psychoBtn 1s linear infinite;}
    @keyframes psychoBtn{to{background-position:200% 0;}}
    #ds-sidebar{position:fixed;right:0;top:50%;transform:translateY(-50%);z-index:9999999;display:flex;flex-direction:column;gap:6px;padding:10px 0;transition:transform .2s;}
    #ds-sidebar.hidden-sidebar{transform:translateY(-50%) translateX(100%);}
    .ds-sbb{width:56px;height:46px;background:#181818;border:1px solid #2a2a2a;border-right:none;border-radius:8px 0 0 8px;color:#777;font-size:9px;font-weight:700;font-family:'Segoe UI',Arial,sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;gap:2px;letter-spacing:.04em;text-transform:uppercase;transition:all .15s;user-select:none;}
    .ds-sbb:hover{background:#222;color:#ccc;border-color:#333;}
    .ds-sbb.active{background:#002a1a;border-color:#00ff88;color:#00ff88;}
    .ds-sbb-icon{font-size:15px;line-height:1;}
    .ds-sbb-key{font-size:8px;color:#333;}
    .ds-sbb.active .ds-sbb-key{color:#005533;}
  `;
  document.head.appendChild(mainCSS);

  // ─── SIDEBAR ─────────────────────────────────────────────────────────────────
  const sidebar = document.createElement('div');
  sidebar.id = 'ds-sidebar';
  sidebar.innerHTML = `
    <div class="ds-sbb" data-panel="style"><span class="ds-sbb-icon">✛</span><span>Style</span><span class="ds-sbb-key">[\\]</span></div>
    <div class="ds-sbb" data-panel="colors"><span class="ds-sbb-icon">🎨</span><span>Colors</span><span class="ds-sbb-key">[O]</span></div>
    <div class="ds-sbb" data-panel="details"><span class="ds-sbb-icon">⚙</span><span>Details</span><span class="ds-sbb-key">[.]</span></div>
    <div class="ds-sbb" data-panel="arms"><span class="ds-sbb-icon">┼</span><span>Arms</span><span class="ds-sbb-key">[I]</span></div>
    <div class="ds-sbb" data-panel="dims"><span class="ds-sbb-icon">⇔</span><span>Dims</span><span class="ds-sbb-key">[/]</span></div>
    <div class="ds-sbb" data-panel="overlays"><span class="ds-sbb-icon">📊</span><span>HUD</span><span class="ds-sbb-key">[\`]</span></div>
  `;
  document.body.appendChild(sidebar);

  // ─── PANELS ──────────────────────────────────────────────────────────────────
  function makePanel(id, title, hint, html) {
    const p = document.createElement('div');
    p.className = 'ds-panel'; p.id = 'ds-panel-' + id;
    p.innerHTML = `<h2>${title}</h2><p class="ds-hint">${hint}</p>${html}`;
    document.body.appendChild(p);
    return p;
  }

  makePanel('style', 'Crosshair Style', 'Press \\ to toggle', `
    <div class="ds-section">Master</div>
    <div class="ds-toggle"><input type="checkbox" id="ds-master"><label for="ds-master">Show Crosshair</label></div>
    <div class="ds-section">Type</div>
    <div class="ds-row"><label>Style</label>
      <select id="ds-style">
        <optgroup label="Cross">
          <option value="cross">Cross (no dot)</option>
          <option value="cross_dot">Cross + Dot</option>
        </optgroup>
        <optgroup label="Circle">
          <option value="circle">Circle</option>
          <option value="circle_cross">Circle + Cross</option>
          <option value="circle_cross_dot">Circle + Cross + Dot</option>
        </optgroup>
        <optgroup label="Dot">
          <option value="dot">Dot only</option>
        </optgroup>
        <optgroup label="Diamond">
          <option value="diamond">Diamond</option>
          <option value="diamond_dot">Diamond + Dot</option>
          <option value="diamond_cross">Diamond + Cross</option>
        </optgroup>
        <optgroup label="Square">
          <option value="square">Square</option>
          <option value="square_dot">Square + Dot</option>
          <option value="square_cross_perp">Square + Cross (⊕)</option>
          <option value="square_cross_perp_dot">Square + Cross + Dot (⊕)</option>
          <option value="square_cross_diag">Square + X (diagonal)</option>
          <option value="square_cross_diag_dot">Square + X + Dot (diagonal)</option>
        </optgroup>
      </select>
    </div>
    <div class="ds-section">🍄 Psychedelic Mode</div>
    <div class="ds-toggle"><input type="checkbox" id="ds-psycho"><label for="ds-psycho">Enable psychedelic mode</label></div>
    <div class="ds-row"><label>Speed</label><input type="range" id="ds-psycho-speed" min="1" max="10" step="1"><span class="ds-val" id="ds-psycho-speed-v">3</span></div>
    <div class="ds-foot">
      <button class="ds-btn ds-btn-save" id="ds-save-style">Save</button>
      <button class="ds-btn ds-btn-reset" id="ds-reset-all">Reset All</button>
    </div>
  `);

  makePanel('colors', 'Colors', 'Press O to toggle', `
    <div class="ds-section">Main Color</div>
    <div class="ds-row"><label>Color</label><input type="color" id="ds-color"><input type="text" id="ds-color-hex" maxlength="7" placeholder="#00ff88"></div>
    <div class="ds-section">Outline Color</div>
    <div class="ds-row"><label>Outline</label><input type="color" id="ds-outline-color"><input type="text" id="ds-outline-hex" maxlength="7" placeholder="#000000"></div>
    <div class="ds-section">Opacity</div>
    <div class="ds-row"><label>Opacity</label><input type="range" id="ds-opacity" min="0.1" max="1" step="0.01"><span class="ds-val" id="ds-opacity-v">100%</span></div>
    <div class="ds-foot"><button class="ds-btn ds-btn-save" id="ds-save-colors">Save</button></div>
  `);

  makePanel('details', 'Details', 'Press . to toggle', `
    <div class="ds-section">Outline</div>
    <div class="ds-toggle"><input type="checkbox" id="ds-outline"><label for="ds-outline">Show outline</label></div>
    <div class="ds-section">Center Dot</div>
    <div class="ds-toggle"><input type="checkbox" id="ds-dot"><label for="ds-dot">Show center dot</label></div>
    <div class="ds-row"><label>Dot size</label><input type="range" id="ds-dot-size" min="1" max="10" step="1"><span class="ds-val" id="ds-dot-size-v">2px</span></div>
    <div class="ds-section">Circle Radius</div>
    <div class="ds-row"><label>Radius</label><input type="range" id="ds-circle-r" min="2" max="40" step="1"><span class="ds-val" id="ds-circle-r-v">14px</span></div>
    <div class="ds-foot"><button class="ds-btn ds-btn-save" id="ds-save-details">Save</button></div>
  `);

  makePanel('arms', 'Arms', 'Press I to toggle', `
    <div class="ds-section">Enable Arms (cross styles)</div>
    <div class="ds-toggle"><input type="checkbox" id="ds-top"><label for="ds-top">Top arm</label></div>
    <div class="ds-toggle"><input type="checkbox" id="ds-bottom"><label for="ds-bottom">Bottom arm</label></div>
    <div class="ds-toggle"><input type="checkbox" id="ds-left"><label for="ds-left">Left arm</label></div>
    <div class="ds-toggle"><input type="checkbox" id="ds-right"><label for="ds-right">Right arm</label></div>
    <div class="ds-foot"><button class="ds-btn ds-btn-save" id="ds-save-arms">Save</button></div>
  `);

  makePanel('dims', 'Dimensions', 'Press / to toggle', `
    <div class="ds-section">Size</div>
    <div class="ds-row"><label>Length</label><input type="range" id="ds-len" min="0" max="50" step="1"><span class="ds-val" id="ds-len-v">12px</span></div>
    <div class="ds-row"><label>Thickness</label><input type="range" id="ds-thick" min="1" max="12" step="1"><span class="ds-val" id="ds-thick-v">2px</span></div>
    <div class="ds-row"><label>Gap</label><input type="range" id="ds-gap" min="0" max="30" step="1"><span class="ds-val" id="ds-gap-v">4px</span></div>
    <div class="ds-foot"><button class="ds-btn ds-btn-save" id="ds-save-dims">Save</button></div>
  `);

  makePanel('overlays', 'HUD Overlays', 'Press ` to toggle', `
    <div class="ds-section">Visibility</div>
    <div class="ds-toggle"><input type="checkbox" id="ds-fps"><label for="ds-fps">Live FPS</label></div>
    <div class="ds-toggle"><input type="checkbox" id="ds-ping"><label for="ds-ping">Live Ping</label></div>
    <div class="ds-toggle"><input type="checkbox" id="ds-keys"><label for="ds-keys">Key Tracker</label></div>
    <div class="ds-section">Overlay Color</div>
    <div class="ds-row"><label>Color</label><input type="color" id="ds-overlay-color"><input type="text" id="ds-overlay-color-hex" maxlength="7" placeholder="#00ff88"></div>
    <div class="ds-section">Preview Box</div>
    <div class="ds-toggle"><input type="checkbox" id="ds-show-preview"><label for="ds-show-preview">Show preview box</label></div>
    <div class="ds-foot"><button class="ds-btn ds-btn-save" id="ds-save-overlays">Save</button></div>
  `);

  // ─── POPULATE & READ ──────────────────────────────────────────────────────────
  function g(id) { return document.getElementById(id); }

  function populate() {
    g('ds-master').checked             = S.masterShow;
    g('ds-style').value                = S.style;
    g('ds-psycho').checked             = S.psychedelic;
    g('ds-psycho-speed').value         = S.psychoSpeed;
    g('ds-psycho-speed-v').textContent = S.psychoSpeed;
    g('ds-color').value                = S.color;
    g('ds-color-hex').value            = S.color;
    g('ds-outline-color').value        = S.outlineColor;
    g('ds-outline-hex').value          = S.outlineColor;
    g('ds-opacity').value              = S.opacity;
    g('ds-opacity-v').textContent      = Math.round(S.opacity * 100) + '%';
    g('ds-outline').checked            = S.showOutline;
    g('ds-dot').checked                = S.showDot;
    g('ds-dot-size').value             = S.dotSize;
    g('ds-dot-size-v').textContent     = S.dotSize + 'px';
    g('ds-circle-r').value             = S.circleRadius;
    g('ds-circle-r-v').textContent     = S.circleRadius + 'px';
    g('ds-top').checked                = S.showTop;
    g('ds-bottom').checked             = S.showBottom;
    g('ds-left').checked               = S.showLeft;
    g('ds-right').checked              = S.showRight;
    g('ds-len').value                  = S.len;
    g('ds-len-v').textContent          = S.len + 'px';
    g('ds-thick').value                = S.thick;
    g('ds-thick-v').textContent        = S.thick + 'px';
    g('ds-gap').value                  = S.gap;
    g('ds-gap-v').textContent          = S.gap + 'px';
    g('ds-fps').checked                = S.showFPS;
    g('ds-ping').checked               = S.showPing;
    g('ds-keys').checked               = S.showKeys;
    g('ds-overlay-color').value        = S.overlayColor;
    g('ds-overlay-color-hex').value    = S.overlayColor;
    g('ds-show-preview').checked       = S.showPreview;
  }

  function readAll() {
    S.masterShow   = g('ds-master').checked;
    S.style        = g('ds-style').value;
    S.psychedelic  = g('ds-psycho').checked;
    S.psychoSpeed  = parseInt(g('ds-psycho-speed').value);
    if (!S.psychedelic) {
      S.color        = g('ds-color').value;
      S.outlineColor = g('ds-outline-color').value;
      S.overlayColor = g('ds-overlay-color').value;
    }
    S.opacity      = parseFloat(g('ds-opacity').value);
    S.showOutline  = g('ds-outline').checked;
    S.showDot      = g('ds-dot').checked;
    S.dotSize      = parseInt(g('ds-dot-size').value);
    S.circleRadius = parseInt(g('ds-circle-r').value);
    S.showTop      = g('ds-top').checked;
    S.showBottom   = g('ds-bottom').checked;
    S.showLeft     = g('ds-left').checked;
    S.showRight    = g('ds-right').checked;
    S.len          = parseInt(g('ds-len').value);
    S.thick        = parseInt(g('ds-thick').value);
    S.gap          = parseInt(g('ds-gap').value);
    S.showFPS      = g('ds-fps').checked;
    S.showPing     = g('ds-ping').checked;
    S.showKeys     = g('ds-keys').checked;
    S.showPreview  = g('ds-show-preview').checked;

    g('ds-psycho-speed-v').textContent = S.psychoSpeed;
    g('ds-opacity-v').textContent      = Math.round(S.opacity * 100) + '%';
    g('ds-dot-size-v').textContent     = S.dotSize + 'px';
    g('ds-circle-r-v').textContent     = S.circleRadius + 'px';
    g('ds-len-v').textContent          = S.len + 'px';
    g('ds-thick-v').textContent        = S.thick + 'px';
    g('ds-gap-v').textContent          = S.gap + 'px';

    // Toggle psycho mode
    if (S.psychedelic) { startPsycho(); }
    else               { stopPsycho(); applyOverlayColor(); applyKeyColor(); }

    updatePreviewVisibility();
    updateOverlays();
    redraw();
  }

  // color pickers <-> hex sync
  g('ds-color').addEventListener('input', e => { g('ds-color-hex').value = e.target.value; readAll(); });
  g('ds-color-hex').addEventListener('input', e => { if (/^#[0-9a-fA-F]{6}$/.test(e.target.value)) { g('ds-color').value = e.target.value; readAll(); } });
  g('ds-outline-color').addEventListener('input', e => { g('ds-outline-hex').value = e.target.value; readAll(); });
  g('ds-outline-hex').addEventListener('input', e => { if (/^#[0-9a-fA-F]{6}$/.test(e.target.value)) { g('ds-outline-color').value = e.target.value; readAll(); } });
  g('ds-overlay-color').addEventListener('input', e => { g('ds-overlay-color-hex').value = e.target.value; readAll(); });
  g('ds-overlay-color-hex').addEventListener('input', e => { if (/^#[0-9a-fA-F]{6}$/.test(e.target.value)) { g('ds-overlay-color').value = e.target.value; readAll(); } });

  [
    'ds-master','ds-style','ds-psycho','ds-psycho-speed','ds-opacity',
    'ds-outline','ds-dot','ds-dot-size','ds-circle-r',
    'ds-top','ds-bottom','ds-left','ds-right',
    'ds-len','ds-thick','ds-gap',
    'ds-fps','ds-ping','ds-keys','ds-show-preview'
  ].forEach(id => {
    const el = g(id); if (!el) return;
    el.addEventListener('input', readAll);
    el.addEventListener('change', readAll);
  });

  // Save buttons
  ['style','colors','details','arms','dims','overlays'].forEach(id => {
    const btn = g('ds-save-' + id);
    if (btn) btn.addEventListener('click', () => {
      save();
      btn.textContent = 'Saved!';
      setTimeout(() => btn.textContent = 'Save', 1500);
    });
  });

  g('ds-reset-all').addEventListener('click', () => {
    S = Object.assign({}, defaults);
    stopPsycho();
    save(); populate(); redraw(); updateOverlays(); updatePreviewVisibility();
  });

  // ─── PANEL TOGGLE ─────────────────────────────────────────────────────────────
  const panelMap = {
    style:'ds-panel-style', colors:'ds-panel-colors', details:'ds-panel-details',
    arms:'ds-panel-arms', dims:'ds-panel-dims', overlays:'ds-panel-overlays'
  };
  let openPanel = null;

  function togglePanel(name) {
    const panelEl = g(panelMap[name]);
    const btnEl = sidebar.querySelector('[data-panel="' + name + '"]');
    if (openPanel && openPanel !== name) {
      g(panelMap[openPanel]).classList.remove('open');
      sidebar.querySelector('[data-panel="' + openPanel + '"]').classList.remove('active');
    }
    if (openPanel === name) {
      panelEl.classList.remove('open'); btnEl.classList.remove('active'); openPanel = null;
    } else {
      populate();
      panelEl.classList.add('open'); btnEl.classList.add('active'); openPanel = name;
    }
  }

  sidebar.querySelectorAll('.ds-sbb').forEach(btn => btn.addEventListener('click', () => togglePanel(btn.dataset.panel)));

  // ─── KEYBOARD BINDINGS ────────────────────────────────────────────────────────
  document.addEventListener('keydown', e => {
    if (e.target.tagName === 'INPUT' && e.target.type === 'text') return;
    const k = e.key;
    if      (k==='u'||k==='U') { sidebar.classList.toggle('hidden-sidebar'); S.sidebarVisible = !sidebar.classList.contains('hidden-sidebar'); }
    else if (k==='\\')          togglePanel('style');
    else if (k==='o'||k==='O') togglePanel('colors');
    else if (k==='.')           togglePanel('details');
    else if (k==='i'||k==='I') togglePanel('arms');
    else if (k==='/') { e.preventDefault(); togglePanel('dims'); }
    else if (k==='`')           togglePanel('overlays');
  });

  // ─── DRAGGABLE PANELS ─────────────────────────────────────────────────────────
  document.querySelectorAll('.ds-panel').forEach(p => {
    let drag = false, ox = 0, oy = 0;
    p.addEventListener('mousedown', e => {
      if (['INPUT','SELECT','BUTTON','LABEL'].includes(e.target.tagName)) return;
      drag = true;
      const r = p.getBoundingClientRect(); ox = e.clientX - r.left; oy = e.clientY - r.top;
      p.style.cursor = 'grabbing'; e.preventDefault();
    });
    document.addEventListener('mousemove', e => {
      if (!drag) return;
      p.style.left = (e.clientX-ox)+'px'; p.style.top = (e.clientY-oy)+'px';
      p.style.right = 'auto'; p.style.transform = 'none';
    });
    document.addEventListener('mouseup', () => { drag = false; p.style.cursor = ''; });
  });

  // ─── INIT ─────────────────────────────────────────────────────────────────────
  if (!S.sidebarVisible) sidebar.classList.add('hidden-sidebar');
  populate();
  redraw();
  updateOverlays();
  updatePreviewVisibility();
  if (S.psychedelic) startPsycho();

})();
