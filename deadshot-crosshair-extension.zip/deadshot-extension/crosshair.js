(function () {
  'use strict';
  if (window.__ds_xhair_v6) return;
  window.__ds_xhair_v6 = true;

  // ─── SETTINGS ────────────────────────────────────────────────────────────────
  const KEY  = 'ds_xhair_v6';
  const IKEY = 'ds_xhair_v6_images';
  const PKEY = 'ds_xhair_v6_presets';

  const defaults = {
    masterShow:     true,
    // Vector
    color:          '#00ff88',
    outlineColor:   '#000000',
    showOutline:    true,
    dotType:        'circle',  // circle|square|diamond|hline|vline
    dotSize:        4,
    style:          'cross',
    showTop: true, showBottom: true, showLeft: true, showRight: true,
    len: 12, thick: 2, gap: 4,
    opacity: 1.0,
    circleRadius: 14,
    // Spin & Breathe
    xhairSpin:       false,
    xhairSpinSpd:    1,
    xhairBreathe:    false,
    xhairBreatheSpd: 1,
    xhairBreatheAmt: 4,
    // Hit marker
    hitMarker:       true,
    hitColor:        '#00ff88',
    hitSize:         10,
    hitThick:        2,
    hitDuration:     150,
    // Psychedelic
    psychedelic:    false,
    psychoSpeed:    3,
    // HUD
    showFPS: true, showPing: true, showKeys: true,
    overlayColor: '#00ff88',
    showPreview:  true,
    sidebarVisible: true,
    // Image modes
    img_full_on:       false,
    img_full_size:     80,
    img_full_spin:     false,
    img_full_spinSpd:  1,
    img_full_opacity:  1.0,
    img_dot_on:        false,
    img_dot_size:      10,
    img_dot_spin:      false,
    img_dot_spinSpd:   2,
    img_arm_on:        false,
    img_arm_size:      8,
    img_arm_spacing:   2,
    // Orbit
    img_orbit_on:      false,
    img_orbit_mode:    'repeat', // repeat|single
    img_orbit_count:   8,
    img_orbit_radius:  30,
    img_orbit_size:    12,
    img_orbit_singleSize: 60,
    img_orbit_spin:    true,
    img_orbit_spinSpd: 1,
    img_orbit_selfSpin:false,
    img_orbit_singleDest: 'orbit', // orbit|center
    img_orbit_shape:   'circle',
  };

  let S = (() => { try { return Object.assign({}, defaults, JSON.parse(localStorage.getItem(KEY))); } catch(e) { return Object.assign({}, defaults); } })();
  let IMG = (() => { try { return JSON.parse(localStorage.getItem(IKEY)) || {}; } catch(e) { return {}; } })();
  let PRESETS = (() => { try { return JSON.parse(localStorage.getItem(PKEY)) || [null,null,null,null,null]; } catch(e) { return [null,null,null,null,null]; } })();
  let BMP = { full:null, dot:null, arm:null, orbit:null };

  function save()      { localStorage.setItem(KEY,  JSON.stringify(S)); }
  function saveImgs()  { localStorage.setItem(IKEY, JSON.stringify(IMG)); }
  function savePresets(){ localStorage.setItem(PKEY, JSON.stringify(PRESETS)); }

  async function decodeBitmap(slot) {
    if (!IMG[slot]) { BMP[slot]=null; return; }
    try { const b=await fetch(IMG[slot]); const bl=await b.blob(); BMP[slot]=await createImageBitmap(bl); }
    catch(e) { BMP[slot]=null; }
  }
  async function decodeAll() { await Promise.all(['full','dot','arm','orbit'].map(decodeBitmap)); scheduleRedraw(); }

  // ─── ANIMATION LOOP ───────────────────────────────────────────────────────────
  const CANVAS_SIZE = 180;
  const PREV_SIZE   = 100;
  const MIN_MS = 1000/30;
  let rafHandle=null, lastFrame=0;
  let angles = { full:0, dot:0, orbit:0, orbitSelf:0, xhair:0 };
  let breatheT = 0;

  function needsAnimation() {
    if (!S.masterShow) return false;
    return S.xhairSpin || S.xhairBreathe ||
      (S.img_full_on  && S.img_full_spin  && BMP.full)  ||
      (S.img_dot_on   && S.img_dot_spin   && BMP.dot)   ||
      (S.img_orbit_on && (S.img_orbit_spin||S.img_orbit_selfSpin) && BMP.orbit) ||
      S.psychedelic;
  }

  function startLoop() { if (rafHandle) return; lastFrame=performance.now(); rafHandle=requestAnimationFrame(loopTick); }
  function stopLoop()  { if (rafHandle) { cancelAnimationFrame(rafHandle); rafHandle=null; } }

  function loopTick(now) {
    const dt = now - lastFrame;
    if (dt >= MIN_MS) {
      lastFrame = now - (dt % MIN_MS);
      const sec = dt/1000;
      if (S.xhairSpin)       angles.xhair     = (angles.xhair     + S.xhairSpinSpd  * sec * 60) % 360;
      if (S.xhairBreathe)    breatheT        += sec * S.xhairBreatheSpd;
      if (S.img_full_spin)   angles.full      = (angles.full      + S.img_full_spinSpd  * sec * 60) % 360;
      if (S.img_dot_spin)    angles.dot       = (angles.dot       + S.img_dot_spinSpd   * sec * 60) % 360;
      if (S.img_orbit_spin)  angles.orbit     = (angles.orbit     + S.img_orbit_spinSpd * sec * 60) % 360;
      if (S.img_orbit_selfSpin) angles.orbitSelf = (angles.orbitSelf + S.img_orbit_spinSpd * sec * 60) % 360;
      renderAll();
    }
    rafHandle = requestAnimationFrame(loopTick);
  }

  function scheduleRedraw() { if (needsAnimation()) startLoop(); else { stopLoop(); renderAll(); } }

  // ─── RENDER ───────────────────────────────────────────────────────────────────
  function renderAll() {
    ctx.clearRect(0,0,CANVAS_SIZE,CANVAS_SIZE);
    if (!S.masterShow) { updatePreviewFromMain(); return; }
    const cx=CANVAS_SIZE/2, cy=CANVAS_SIZE/2;
    ctx.globalAlpha = S.opacity;

    // Breathe: scale offset applied to len
    const breatheOff = S.xhairBreathe ? Math.sin(breatheT * Math.PI * 2) * S.xhairBreatheAmt : 0;
    const sWithBreathe = Object.assign({}, S, { len: S.len + breatheOff });

    if (S.xhairSpin) {
      ctx.save();
      ctx.translate(cx,cy);
      ctx.rotate(angles.xhair * Math.PI/180);
      ctx.translate(-cx,-cy);
    }

    // Layers
    if (!S.img_full_on || !BMP.full)      drawVector(ctx, cx, cy, sWithBreathe);
    if (S.img_orbit_on && BMP.orbit)      drawOrbit(ctx, cx, cy);
    if (S.img_full_on  && BMP.full)       drawFull(ctx, cx, cy);
    if (S.img_arm_on   && BMP.arm)        drawArms(ctx, cx, cy, sWithBreathe);
    if (S.img_dot_on   && BMP.dot)        drawDot(ctx, cx, cy);

    if (S.xhairSpin) ctx.restore();
    ctx.globalAlpha = 1;
    updatePreviewFromMain();
  }

  function updatePreviewFromMain() {
    if (!S.showPreview) return;
    pctx.clearRect(0,0,PREV_SIZE,PREV_SIZE);
    const scale = PREV_SIZE/CANVAS_SIZE;
    pctx.save(); pctx.scale(scale,scale); pctx.drawImage(cv,0,0); pctx.restore();
  }

  // ─── VECTOR CROSSHAIR ─────────────────────────────────────────────────────────
  function drawVector(context, cx, cy, s) {
    const g2=s.gap, l=s.len, t=s.thick, col=s.color, out=s.outlineColor;

    function applyOutline(fn) {
      if (s.showOutline) { context.strokeStyle=out; context.lineWidth=t+2; context.lineCap='square'; fn(); context.stroke(); }
      context.strokeStyle=col; context.lineWidth=t; context.lineCap='square'; fn(); context.stroke();
    }

    function drawDotShape() {
      const ds = s.dotSize;
      if (s.dotType==='circle') {
        if (s.showOutline) { context.fillStyle=out; context.beginPath(); context.arc(cx,cy,ds+1,0,Math.PI*2); context.fill(); }
        context.fillStyle=col; context.beginPath(); context.arc(cx,cy,ds,0,Math.PI*2); context.fill();
      } else if (s.dotType==='square') {
        if (s.showOutline) { context.fillStyle=out; context.fillRect(cx-ds-1,cy-ds-1,(ds+1)*2,(ds+1)*2); }
        context.fillStyle=col; context.fillRect(cx-ds,cy-ds,ds*2,ds*2);
      } else if (s.dotType==='diamond') {
        if (s.showOutline) { context.strokeStyle=out; context.lineWidth=2; context.lineJoin='miter'; context.beginPath(); context.moveTo(cx,cy-ds-1); context.lineTo(cx+ds+1,cy); context.lineTo(cx,cy+ds+1); context.lineTo(cx-ds-1,cy); context.closePath(); context.stroke(); }
        context.fillStyle=col; context.beginPath(); context.moveTo(cx,cy-ds); context.lineTo(cx+ds,cy); context.lineTo(cx,cy+ds); context.lineTo(cx-ds,cy); context.closePath(); context.fill();
      } else if (s.dotType==='hline') {
        applyOutline(()=>{ context.beginPath(); context.moveTo(cx-ds*2,cy); context.lineTo(cx+ds*2,cy); });
      } else if (s.dotType==='vline') {
        applyOutline(()=>{ context.beginPath(); context.moveTo(cx,cy-ds*2); context.lineTo(cx,cy+ds*2); });
      }
    }

    function crossArms() {
      if (s.showLeft)   applyOutline(()=>{ context.beginPath(); context.moveTo(cx-g2-l,cy); context.lineTo(cx-g2,cy); });
      if (s.showRight)  applyOutline(()=>{ context.beginPath(); context.moveTo(cx+g2,cy); context.lineTo(cx+g2+l,cy); });
      if (s.showTop)    applyOutline(()=>{ context.beginPath(); context.moveTo(cx,cy-g2-l); context.lineTo(cx,cy-g2); });
      if (s.showBottom) applyOutline(()=>{ context.beginPath(); context.moveTo(cx,cy+g2); context.lineTo(cx,cy+g2+l); });
    }
    function circle()  { applyOutline(()=>{ context.beginPath(); context.arc(cx,cy,s.circleRadius,0,Math.PI*2); }); }
    function diamond() {
      const r=l+g2;
      if (s.showOutline) { context.strokeStyle=out; context.lineWidth=t+2; context.lineJoin='miter'; context.beginPath(); context.moveTo(cx,cy-r); context.lineTo(cx+r,cy); context.lineTo(cx,cy+r); context.lineTo(cx-r,cy); context.closePath(); context.stroke(); }
      context.strokeStyle=col; context.lineWidth=t; context.lineJoin='miter'; context.beginPath(); context.moveTo(cx,cy-r); context.lineTo(cx+r,cy); context.lineTo(cx,cy+r); context.lineTo(cx-r,cy); context.closePath(); context.stroke();
    }
    function square() {
      const r=l+g2;
      if (s.showOutline) { context.strokeStyle=out; context.lineWidth=t+2; context.lineJoin='miter'; context.strokeRect(cx-r,cy-r,r*2,r*2); }
      context.strokeStyle=col; context.lineWidth=t; context.lineJoin='miter'; context.strokeRect(cx-r,cy-r,r*2,r*2);
    }
    function diagArms() {
      const d=(g2+l)*Math.SQRT1_2, gd=g2*Math.SQRT1_2;
      applyOutline(()=>{ context.beginPath(); context.moveTo(cx-gd,cy-gd); context.lineTo(cx-d,cy-d); });
      applyOutline(()=>{ context.beginPath(); context.moveTo(cx+gd,cy-gd); context.lineTo(cx+d,cy-d); });
      applyOutline(()=>{ context.beginPath(); context.moveTo(cx+gd,cy+gd); context.lineTo(cx+d,cy+d); });
      applyOutline(()=>{ context.beginPath(); context.moveTo(cx-gd,cy+gd); context.lineTo(cx-d,cy+d); });
    }

    const st=s.style;
    if      (st==='cross')                { crossArms(); }
    else if (st==='cross_dot')            { crossArms(); drawDotShape(); }
    else if (st==='dot')                  { drawDotShape(); }
    else if (st==='circle')               { circle(); }
    else if (st==='circle_cross')         { circle(); crossArms(); }
    else if (st==='circle_cross_dot')     { circle(); crossArms(); drawDotShape(); }
    else if (st==='diamond')              { diamond(); }
    else if (st==='diamond_dot')          { diamond(); drawDotShape(); }
    else if (st==='diamond_cross')        { diamond(); crossArms(); }
    else if (st==='square')               { square(); }
    else if (st==='square_dot')           { square(); drawDotShape(); }
    else if (st==='square_cross_perp')    { square(); crossArms(); }
    else if (st==='square_cross_perp_dot'){ square(); crossArms(); drawDotShape(); }
    else if (st==='square_cross_diag')    { square(); diagArms(); }
    else if (st==='square_cross_diag_dot'){ square(); diagArms(); drawDotShape(); }
  }

  // ─── IMAGE HELPERS ────────────────────────────────────────────────────────────
  function drawImgCentered(context, bmp, x, y, size, angleDeg) {
    const half=size/2;
    context.save(); context.translate(x,y);
    if (angleDeg) context.rotate(angleDeg*Math.PI/180);
    context.drawImage(bmp,-half,-half,size,size);
    context.restore();
  }

  function drawFull(context, cx, cy) {
    context.save(); context.globalAlpha=S.img_full_opacity*S.opacity;
    drawImgCentered(context,BMP.full,cx,cy,S.img_full_size,S.img_full_spin?angles.full:0);
    context.restore();
  }

  function drawDot(context, cx, cy) {
    drawImgCentered(context,BMP.dot,cx,cy,S.img_dot_size,S.img_dot_spin?angles.dot:0);
  }

  function drawArms(context, cx, cy, s) {
    const g2=s.gap, l=s.len, ts=S.img_arm_size, sp=S.img_arm_spacing;
    const step=ts+sp, count=Math.max(1,Math.floor(l/step));
    const dirs=[[-1,0,s.showLeft],[1,0,s.showRight],[0,-1,s.showTop],[0,1,s.showBottom]];
    dirs.forEach(([dx,dy,on])=>{
      if(!on) return;
      for(let i=0;i<count;i++){
        const dist=g2+ts/2+i*step;
        drawImgCentered(context,BMP.arm,cx+dx*dist,cy+dy*dist,ts,0);
      }
    });
  }

  function drawOrbit(context, cx, cy) {
    const shape=S.img_orbit_shape;
    const baseAngle=S.img_orbit_spin?(angles.orbit*Math.PI/180):0;

    if (S.img_orbit_mode==='single') {
      if (S.img_orbit_singleDest==='center') {
        // Single image at center, optionally spinning
        drawImgCentered(context,BMP.orbit,cx,cy,S.img_orbit_singleSize,S.img_orbit_selfSpin?angles.orbitSelf:0);
      } else {
        // Single image traveling around the orbit path
        const a = baseAngle;
        const {x,y} = orbitPos(cx,cy,a,shape,S.img_orbit_radius);
        drawImgCentered(context,BMP.orbit,x,y,S.img_orbit_singleSize,S.img_orbit_selfSpin?angles.orbitSelf:0);
      }
    } else {
      // Repeat mode — stamp N copies around the path
      for(let i=0;i<S.img_orbit_count;i++){
        const a = baseAngle + (i/S.img_orbit_count)*Math.PI*2;
        const {x,y} = orbitPos(cx,cy,a,shape,S.img_orbit_radius);
        drawImgCentered(context,BMP.orbit,x,y,S.img_orbit_size,S.img_orbit_selfSpin?angles.orbitSelf:0);
      }
    }
  }

  function orbitPos(cx, cy, a, shape, radius) {
    if (shape==='circle') {
      return { x: cx+Math.cos(a)*radius, y: cy+Math.sin(a)*radius };
    } else if (shape==='oval') {
      return { x: cx+Math.cos(a)*radius, y: cy+Math.sin(a)*radius*0.55 };
    } else { // square
      const t2=((a/(Math.PI*2)*4)%4+4)%4, side=radius*1.4;
      let x,y;
      if      (t2<1) { x=cx-side+t2*2*side; y=cy-side; }
      else if (t2<2) { x=cx+side; y=cy-side+(t2-1)*2*side; }
      else if (t2<3) { x=cx+side-(t2-2)*2*side; y=cy+side; }
      else           { x=cx-side; y=cy+side-(t2-3)*2*side; }
      return {x,y};
    }
  }

  // ─── HIT MARKER ──────────────────────────────────────────────────────────────
  let hitTimeout=null;
  const hitCv = document.createElement('canvas');
  hitCv.width=hitCv.height=80;
  Object.assign(hitCv.style,{position:'fixed',top:'50%',left:'50%',transform:'translate(-50%,-50%)',pointerEvents:'none',zIndex:'999999',opacity:'0',transition:'opacity 0.05s'});
  document.body.appendChild(hitCv);
  const hctx = hitCv.getContext('2d');

  function drawHitMarker() {
    hctx.clearRect(0,0,80,80);
    const cx=40,cy=40,sz=S.hitSize,t=S.hitThick;
    hctx.strokeStyle=S.hitColor;
    hctx.lineWidth=t;
    hctx.lineCap='square';
    // 4 diagonal ticks
    const d=6;
    [[cx-d,cy-d,cx-d-sz,cy-d-sz],[cx+d,cy-d,cx+d+sz,cy-d-sz],
     [cx+d,cy+d,cx+d+sz,cy+d+sz],[cx-d,cy+d,cx-d-sz,cy+d+sz]].forEach(([x1,y1,x2,y2])=>{
      hctx.beginPath(); hctx.moveTo(x1,y1); hctx.lineTo(x2,y2); hctx.stroke();
    });
  }

  function flashHitMarker() {
    if(!S.hitMarker||!S.masterShow) return;
    drawHitMarker();
    hitCv.style.opacity='1';
    if(hitTimeout) clearTimeout(hitTimeout);
    hitTimeout=setTimeout(()=>{ hitCv.style.opacity='0'; },S.hitDuration);
  }

  window.addEventListener('mousedown', e=>{ if(e.button===0) flashHitMarker(); });

  // ─── CANVAS ───────────────────────────────────────────────────────────────────
  const cv=document.createElement('canvas');
  cv.width=cv.height=CANVAS_SIZE;
  Object.assign(cv.style,{position:'fixed',top:'50%',left:'50%',transform:'translate(-50%,-50%)',pointerEvents:'none',zIndex:'999998',imageRendering:'pixelated'});
  document.body.appendChild(cv);
  const ctx=cv.getContext('2d');

  // Preview
  const prevWrap=document.createElement('div');
  prevWrap.style.cssText='position:fixed;bottom:20px;right:20px;z-index:9999996;background:#111;border:1px solid #2a2a2a;border-radius:10px;width:120px;height:120px;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 20px rgba(0,0,0,.7);cursor:grab;user-select:none;';
  const prevLbl=document.createElement('div');
  prevLbl.textContent='PREVIEW';
  prevLbl.style.cssText='position:absolute;top:5px;left:50%;transform:translateX(-50%);font:700 9px Consolas,monospace;color:#333;letter-spacing:.08em;pointer-events:none;';
  const prevCv=document.createElement('canvas');
  prevCv.width=prevCv.height=PREV_SIZE;
  prevCv.style.pointerEvents='none';
  const pctx=prevCv.getContext('2d');
  prevWrap.appendChild(prevLbl); prevWrap.appendChild(prevCv);
  document.body.appendChild(prevWrap);

  (function(){
    let drag=false,ox=0,oy=0;
    prevWrap.addEventListener('mousedown',e=>{ drag=true; const r=prevWrap.getBoundingClientRect(); ox=e.clientX-r.left; oy=e.clientY-r.top; prevWrap.style.cursor='grabbing'; e.preventDefault(); });
    document.addEventListener('mousemove',e=>{ if(!drag) return; prevWrap.style.left=(e.clientX-ox)+'px'; prevWrap.style.top=(e.clientY-oy)+'px'; prevWrap.style.right='auto'; prevWrap.style.bottom='auto'; });
    document.addEventListener('mouseup',()=>{ drag=false; prevWrap.style.cursor='grab'; });
  })();

  // ─── PSYCHEDELIC ─────────────────────────────────────────────────────────────
  let psychoInterval=null;
  const psychoCSS=document.createElement('style');
  psychoCSS.textContent=`@keyframes ds-hue{from{filter:hue-rotate(0deg)}to{filter:hue-rotate(360deg)}}.ds-psycho-active{animation:ds-hue var(--ds-psycho-dur,3s) linear infinite!important;}`;
  document.head.appendChild(psychoCSS);
  function getPsychoDur(){ return (8.8-S.psychoSpeed*0.8).toFixed(1)+'s'; }

  function startPsycho(){
    if(psychoInterval) return;
    S.color='#ff0000'; S.outlineColor='#00ffff'; renderAll();
    document.documentElement.style.setProperty('--ds-psycho-dur',getPsychoDur());
    [cv,prevCv].forEach(el=>el.classList.add('ds-psycho-active'));
    ['ds-fps-el','ds-ping-el','ds-keys-el'].forEach(id=>{
      const el=document.getElementById(id);
      if(el){ if(id!=='ds-keys-el') el.style.color='#ff0000'; el.classList.add('ds-psycho-active'); }
    });
    psychoInterval=setInterval(()=>{ S.overlayColor=S.color; },2000);
  }

  function stopPsycho(){
    if(psychoInterval){ clearInterval(psychoInterval); psychoInterval=null; }
    [cv,prevCv].forEach(el=>el.classList.remove('ds-psycho-active'));
    ['ds-fps-el','ds-ping-el','ds-keys-el'].forEach(id=>{ const el=document.getElementById(id); if(el) el.classList.remove('ds-psycho-active'); });
    applyOverlayColor(); renderAll();
  }

  // ─── HUD ─────────────────────────────────────────────────────────────────────
  const overlayEl=document.createElement('div');
  overlayEl.style.cssText='position:fixed!important;top:15px!important;left:15px!important;z-index:9999995!important;pointer-events:none!important;display:flex!important;flex-direction:column!important;gap:10px!important;user-select:none!important;';
  overlayEl.innerHTML=`
    <div id="ds-fps-el"  style="font-size:17px;font-weight:700;font-family:Consolas,monospace;text-shadow:1px 1px 0 #000,-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000;">FPS: --</div>
    <div id="ds-ping-el" style="font-size:17px;font-weight:700;font-family:Consolas,monospace;text-shadow:1px 1px 0 #000,-1px -1px 0 #000,1px -1px 0 #000,-1px 1px 0 #000;">PING: --ms</div>
    <div id="ds-keys-el" style="display:flex;flex-direction:column;gap:4px;margin-top:6px;"></div>
  `;
  document.body.appendChild(overlayEl);

  const kbCSS=document.createElement('style');
  kbCSS.textContent=`.ds-kb{background:rgba(0,0,0,.6);border:2px solid var(--ds-overlay-col,#00ff88);color:var(--ds-overlay-col,#00ff88);border-radius:4px;min-width:33px;height:33px;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;padding:0 5px;font-family:Consolas,monospace;}.ds-kb.active{background:var(--ds-overlay-col,#00ff88);color:#000;transform:scale(.93);box-shadow:0 0 8px var(--ds-overlay-col,#00ff88);}`;
  document.head.appendChild(kbCSS);
  document.getElementById('ds-keys-el').innerHTML=`
    <div style="display:flex;gap:4px;justify-content:center;"><div class="ds-kb" id="kb-Mouse0">LMB</div><div class="ds-kb" id="kb-KeyW">W</div><div class="ds-kb" id="kb-Mouse2">RMB</div></div>
    <div style="display:flex;gap:4px;"><div class="ds-kb" id="kb-KeyA">A</div><div class="ds-kb" id="kb-KeyS">S</div><div class="ds-kb" id="kb-KeyD">D</div></div>
    <div style="display:flex;gap:4px;"><div class="ds-kb" id="kb-ShiftLeft" style="min-width:50px">SHFT</div><div class="ds-kb" id="kb-Space" style="flex:1">SPC</div><div class="ds-kb" id="kb-KeyR">R</div><div class="ds-kb" id="kb-KeyF">F</div></div>
  `;

  function applyOverlayColor(){
    const c=S.overlayColor;
    document.documentElement.style.setProperty('--ds-overlay-col',c);
    const fps=document.getElementById('ds-fps-el'),ping=document.getElementById('ds-ping-el');
    if(fps) fps.style.color=c; if(ping) ping.style.color=c;
  }

  let frames=0,lastT=performance.now();
  (function fpsLoop(){ frames++; const now=performance.now(); if(now-lastT>=1000){ const el=document.getElementById('ds-fps-el'); if(el) el.textContent='FPS: '+frames; frames=0; lastT=now; } requestAnimationFrame(fpsLoop); })();
  setInterval(async()=>{ const el=document.getElementById('ds-ping-el'); if(!el) return; const t=performance.now(); try{await fetch(location.origin+'/?ping='+Date.now(),{method:'HEAD',cache:'no-store'});}catch(e){} el.textContent='PING: '+Math.round(performance.now()-t)+'ms'; },2000);

  const hk=(code,down)=>{ const el=document.getElementById('kb-'+code); if(el) el.classList.toggle('active',down); };
  window.addEventListener('keydown',e=>hk(e.code,true));
  window.addEventListener('keyup',e=>hk(e.code,false));
  window.addEventListener('mousedown',e=>hk('Mouse'+e.button,true));
  window.addEventListener('mouseup',e=>hk('Mouse'+e.button,false));

  function updateOverlays(){
    ['ds-fps-el','ds-ping-el','ds-keys-el'].forEach((id,i)=>{
      const el=document.getElementById(id);
      if(el) el.style.display=[S.showFPS,S.showPing,S.showKeys][i]?'':'none';
    });
    applyOverlayColor();
  }

  // ─── CSS ─────────────────────────────────────────────────────────────────────
  const mainCSS=document.createElement('style');
  mainCSS.textContent=`
    .ds-panel{display:none;position:fixed;top:50%;right:70px;transform:translateY(-50%);z-index:9999997;background:#181818;border:1px solid #2a2a2a;border-radius:12px;width:310px;max-height:84vh;overflow-y:auto;overflow-x:hidden;padding:18px 18px 14px;font-family:'Segoe UI',Arial,sans-serif;color:#e0e0e0;box-shadow:0 8px 32px rgba(0,0,0,.85);scrollbar-width:thin;scrollbar-color:#333 #111;}
    .ds-panel::-webkit-scrollbar{width:5px;}.ds-panel::-webkit-scrollbar-track{background:#111;}.ds-panel::-webkit-scrollbar-thumb{background:#333;border-radius:3px;}
    .ds-panel.open{display:block;}
    .ds-panel h2{margin:0 0 2px;font-size:14px;font-weight:700;color:#fff;letter-spacing:.05em;text-transform:uppercase;}
    .ds-hint{font-size:10px;color:#444;margin:0 0 14px;}
    .ds-section{font-size:9px;text-transform:uppercase;letter-spacing:.1em;color:#444;margin:14px 0 8px;border-top:1px solid #222;padding-top:8px;}
    .ds-row{display:flex;align-items:center;gap:8px;margin-bottom:9px;}
    .ds-row label{font-size:12px;color:#999;min-width:92px;}
    .ds-row input[type=range]{flex:1;accent-color:#00ff88;height:3px;cursor:pointer;}
    .ds-val{font-size:12px;font-weight:700;min-width:32px;text-align:right;color:#fff;font-family:Consolas,monospace;}
    .ds-row input[type=color]{width:32px;height:24px;border:none;border-radius:4px;cursor:pointer;padding:1px;background:none;}
    .ds-row input[type=text]{flex:1;background:#222;color:#eee;border:1px solid #2a2a2a;border-radius:5px;padding:4px 7px;font-size:12px;font-family:Consolas,monospace;outline:none;}
    .ds-row select{flex:1;background:#222;color:#eee;border:1px solid #2a2a2a;border-radius:5px;padding:5px 7px;font-size:12px;outline:none;}
    .ds-toggle{display:flex;align-items:center;gap:8px;margin-bottom:9px;}
    .ds-toggle label{font-size:12px;color:#999;flex:1;cursor:pointer;}
    .ds-toggle input[type=checkbox]{width:14px;height:14px;accent-color:#00ff88;cursor:pointer;}
    .ds-foot{display:flex;gap:8px;margin-top:14px;padding-top:12px;border-top:1px solid #222;}
    .ds-btn{flex:1;padding:8px 0;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;border:none;letter-spacing:.04em;}
    .ds-btn-save{background:#00ff88;color:#000;}.ds-btn-save:hover{background:#00cc6a;}
    .ds-btn-reset{background:#2a2a2a;color:#888;}.ds-btn-reset:hover{background:#333;color:#fff;}
    .ds-btn-danger{background:#3a0a0a;color:#ff4444;border:1px solid #ff444444;}.ds-btn-danger:hover{background:#ff4444;color:#000;}
    .ds-upload-btn{width:100%;padding:8px;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;border:1px dashed #444;background:#1e1e1e;color:#aaa;text-align:center;margin-bottom:6px;display:block;}
    .ds-upload-btn:hover{border-color:#00ff88;color:#00ff88;}
    .ds-img-preview{width:56px;height:56px;border-radius:6px;background:#111;border:1px solid #2a2a2a;object-fit:contain;display:none;}
    .ds-img-preview.has-img{display:block;}
    .ds-img-row{display:flex;align-items:center;gap:10px;margin-bottom:10px;}
    .ds-clear-btn{font-size:10px;padding:3px 8px;border-radius:4px;border:1px solid #444;background:transparent;color:#888;cursor:pointer;}
    .ds-clear-btn:hover{border-color:#ff4444;color:#ff4444;}
    .ds-preset-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:5px;margin-bottom:10px;}
    .ds-preset-btn{padding:5px 0;border-radius:6px;font-size:10px;font-weight:700;cursor:pointer;border:1px solid #333;background:#222;color:#888;text-align:center;}
    .ds-preset-btn:hover{border-color:#00ff88;color:#00ff88;}
    .ds-preset-btn.filled{border-color:#00ff88;color:#00ff88;background:#001a0e;}
    .ds-arm-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:10px;}
    .ds-arm-toggle{padding:8px;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;border:1px solid #333;background:#222;color:#666;text-align:center;transition:all .1s;}
    .ds-arm-toggle.on{border-color:#00ff88;color:#00ff88;background:#001a0e;}
    #ds-sidebar{position:fixed;right:0;top:50%;transform:translateY(-50%);z-index:9999999;display:flex;flex-direction:column;gap:6px;padding:10px 0;transition:transform .2s;}
    #ds-sidebar.hidden-sidebar{transform:translateY(-50%) translateX(100%);}
    .ds-sbb{width:56px;height:46px;background:#181818;border:1px solid #2a2a2a;border-right:none;border-radius:8px 0 0 8px;color:#777;font-size:9px;font-weight:700;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;gap:2px;letter-spacing:.04em;text-transform:uppercase;transition:all .15s;user-select:none;}
    .ds-sbb:hover{background:#222;color:#ccc;border-color:#333;}
    .ds-sbb.active{background:#002a1a;border-color:#00ff88;color:#00ff88;}
    .ds-sbb-icon{font-size:15px;line-height:1;}
    .ds-sbb-key{font-size:8px;color:#333;}
    .ds-sbb.active .ds-sbb-key{color:#005533;}
  `;
  document.head.appendChild(mainCSS);

  // ─── SIDEBAR ─────────────────────────────────────────────────────────────────
  const sidebar=document.createElement('div');
  sidebar.id='ds-sidebar';
  sidebar.innerHTML=`
    <div class="ds-sbb" data-panel="style"><span class="ds-sbb-icon">✛</span><span>Style</span><span class="ds-sbb-key">[\\]</span></div>
    <div class="ds-sbb" data-panel="colors"><span class="ds-sbb-icon">🎨</span><span>Colors</span><span class="ds-sbb-key">[O]</span></div>
    <div class="ds-sbb" data-panel="details"><span class="ds-sbb-icon">⚙</span><span>Details</span><span class="ds-sbb-key">[.]</span></div>
    <div class="ds-sbb" data-panel="arms"><span class="ds-sbb-icon">┼</span><span>Arms</span><span class="ds-sbb-key">[I]</span></div>
    <div class="ds-sbb" data-panel="dims"><span class="ds-sbb-icon">⇔</span><span>Dims</span><span class="ds-sbb-key">[/]</span></div>
    <div class="ds-sbb" data-panel="images"><span class="ds-sbb-icon">🖼</span><span>Images</span><span class="ds-sbb-key">[P]</span></div>
    <div class="ds-sbb" data-panel="presets"><span class="ds-sbb-icon">💾</span><span>Presets</span><span class="ds-sbb-key">[K]</span></div>
    <div class="ds-sbb" data-panel="overlays"><span class="ds-sbb-icon">📊</span><span>HUD</span><span class="ds-sbb-key">[\`]</span></div>
  `;
  document.body.appendChild(sidebar);

  // ─── PANELS ──────────────────────────────────────────────────────────────────
  function makePanel(id,title,hint,html){
    const p=document.createElement('div'); p.className='ds-panel'; p.id='ds-panel-'+id;
    p.innerHTML=`<h2>${title}</h2><p class="ds-hint">${hint}</p>${html}`;
    document.body.appendChild(p); return p;
  }

  makePanel('style','Crosshair Style','Press \\ to toggle',`
    <div class="ds-section">Master</div>
    <div class="ds-toggle"><input type="checkbox" id="ds-master"><label for="ds-master">Show Crosshair</label></div>
    <div class="ds-section">Type</div>
    <div class="ds-row"><label>Style</label>
      <select id="ds-style">
        <optgroup label="Cross"><option value="cross">Cross</option><option value="cross_dot">Cross + Dot</option></optgroup>
        <optgroup label="Circle"><option value="circle">Circle</option><option value="circle_cross">Circle + Cross</option><option value="circle_cross_dot">Circle + Cross + Dot</option></optgroup>
        <optgroup label="Dot"><option value="dot">Dot only</option></optgroup>
        <optgroup label="Diamond"><option value="diamond">Diamond</option><option value="diamond_dot">Diamond + Dot</option><option value="diamond_cross">Diamond + Cross</option></optgroup>
        <optgroup label="Square"><option value="square">Square</option><option value="square_dot">Square + Dot</option><option value="square_cross_perp">Square + Cross ⊕</option><option value="square_cross_perp_dot">Square + Cross + Dot ⊕</option><option value="square_cross_diag">Square + X</option><option value="square_cross_diag_dot">Square + X + Dot</option></optgroup>
      </select>
    </div>
    <div class="ds-section">Motion</div>
    <div class="ds-toggle"><input type="checkbox" id="ds-spin"><label for="ds-spin">Spin crosshair</label></div>
    <div class="ds-row"><label>Spin speed</label><input type="range" id="ds-spin-spd" min="0.1" max="15" step="0.1"><span class="ds-val" id="ds-spin-spd-v">1</span></div>
    <div class="ds-toggle"><input type="checkbox" id="ds-breathe"><label for="ds-breathe">Breathe (pulse)</label></div>
    <div class="ds-row"><label>Breathe speed</label><input type="range" id="ds-breathe-spd" min="0.1" max="5" step="0.1"><span class="ds-val" id="ds-breathe-spd-v">1</span></div>
    <div class="ds-row"><label>Breathe amount</label><input type="range" id="ds-breathe-amt" min="1" max="20" step="1"><span class="ds-val" id="ds-breathe-amt-v">4px</span></div>
    <div class="ds-section">🍄 Psychedelic Mode</div>
    <div class="ds-toggle"><input type="checkbox" id="ds-psycho"><label for="ds-psycho">Enable psychedelic mode</label></div>
    <div class="ds-row"><label>Speed</label><input type="range" id="ds-psycho-speed" min="1" max="10" step="1"><span class="ds-val" id="ds-psycho-speed-v">3</span></div>
    <div class="ds-foot">
      <button class="ds-btn ds-btn-save" id="ds-save-style">Save</button>
      <button class="ds-btn ds-btn-reset" id="ds-reset-all">Reset All</button>
    </div>
  `);

  makePanel('colors','Colors','Press O to toggle',`
    <div class="ds-section">Main Color</div>
    <div class="ds-row"><label>Color</label><input type="color" id="ds-color"><input type="text" id="ds-color-hex" maxlength="7" placeholder="#00ff88"></div>
    <div class="ds-section">Outline Color</div>
    <div class="ds-row"><label>Outline</label><input type="color" id="ds-outline-color"><input type="text" id="ds-outline-hex" maxlength="7" placeholder="#000000"></div>
    <div class="ds-section">Opacity</div>
    <div class="ds-row"><label>Opacity</label><input type="range" id="ds-opacity" min="0.1" max="1" step="0.01"><span class="ds-val" id="ds-opacity-v">100%</span></div>
    <div class="ds-section">⚡ Hit Marker</div>
    <div class="ds-toggle"><input type="checkbox" id="ds-hit-on"><label for="ds-hit-on">Enable hit marker</label></div>
    <div class="ds-row"><label>Color</label><input type="color" id="ds-hit-color"><input type="text" id="ds-hit-hex" maxlength="7" placeholder="#00ff88"></div>
    <div class="ds-row"><label>Size</label><input type="range" id="ds-hit-size" min="4" max="30" step="1"><span class="ds-val" id="ds-hit-size-v">10px</span></div>
    <div class="ds-row"><label>Thickness</label><input type="range" id="ds-hit-thick" min="1" max="6" step="1"><span class="ds-val" id="ds-hit-thick-v">2px</span></div>
    <div class="ds-row"><label>Duration</label><input type="range" id="ds-hit-dur" min="50" max="500" step="10"><span class="ds-val" id="ds-hit-dur-v">150ms</span></div>
    <div class="ds-foot"><button class="ds-btn ds-btn-save" id="ds-save-colors">Save</button></div>
  `);

  makePanel('details','Details','Press . to toggle',`
    <div class="ds-section">Outline</div>
    <div class="ds-toggle"><input type="checkbox" id="ds-outline"><label for="ds-outline">Show outline</label></div>
    <div class="ds-section">Dot Type</div>
    <div class="ds-row"><label>Type</label>
      <select id="ds-dot-type">
        <option value="circle">Circle</option>
        <option value="square">Square</option>
        <option value="diamond">Diamond</option>
        <option value="hline">Horizontal line</option>
        <option value="vline">Vertical line</option>
      </select>
    </div>
    <div class="ds-row"><label>Dot size</label><input type="range" id="ds-dot-size" min="1" max="30" step="1"><span class="ds-val" id="ds-dot-size-v">4px</span></div>
    <div class="ds-section">Circle Radius</div>
    <div class="ds-row"><label>Radius</label><input type="range" id="ds-circle-r" min="2" max="60" step="1"><span class="ds-val" id="ds-circle-r-v">14px</span></div>
    <div class="ds-foot"><button class="ds-btn ds-btn-save" id="ds-save-details">Save</button></div>
  `);

  makePanel('arms','Arms','Press I to toggle — click buttons to toggle each arm',`
    <div class="ds-section">Toggle Arms</div>
    <div class="ds-arm-grid">
      <div class="ds-arm-toggle" id="arm-top"    data-arm="top">↑ Top</div>
      <div class="ds-arm-toggle" id="arm-right"  data-arm="right">→ Right</div>
      <div class="ds-arm-toggle" id="arm-left"   data-arm="left">← Left</div>
      <div class="ds-arm-toggle" id="arm-bottom" data-arm="bottom">↓ Bottom</div>
    </div>
    <div class="ds-foot"><button class="ds-btn ds-btn-save" id="ds-save-arms">Save</button></div>
  `);

  // Arm toggle — delegated listener, no inline onclick (CSP blocks those in extensions)
  document.addEventListener('click', function(e) {
    const btn = e.target.closest('[data-arm]');
    if (!btn) return;
    btn.classList.toggle('on');
    S.showTop    = document.getElementById('arm-top').classList.contains('on');
    S.showRight  = document.getElementById('arm-right').classList.contains('on');
    S.showLeft   = document.getElementById('arm-left').classList.contains('on');
    S.showBottom = document.getElementById('arm-bottom').classList.contains('on');
    save();
    scheduleRedraw();
  });

  makePanel('dims','Dimensions','Press / to toggle',`
    <div class="ds-section">Size</div>
    <div class="ds-row"><label>Length</label><input type="range" id="ds-len" min="0" max="60" step="1"><span class="ds-val" id="ds-len-v">12px</span></div>
    <div class="ds-row"><label>Thickness</label><input type="range" id="ds-thick" min="1" max="16" step="1"><span class="ds-val" id="ds-thick-v">2px</span></div>
    <div class="ds-row"><label>Gap</label><input type="range" id="ds-gap" min="0" max="30" step="1"><span class="ds-val" id="ds-gap-v">4px</span></div>
    <div class="ds-foot"><button class="ds-btn ds-btn-save" id="ds-save-dims">Save</button></div>
  `);

  makePanel('images','Custom Images','Press P to toggle — PNG, JPG, SVG. All 4 modes simultaneously.',`
    <div class="ds-section">Mode 1 — Full Crosshair Image</div>
    <div class="ds-img-row">
      <img class="ds-img-preview" id="ds-prev-full">
      <div style="flex:1"><label class="ds-upload-btn" for="ds-upload-full">📁 Upload</label><input type="file" id="ds-upload-full" accept="image/*" style="display:none"><button class="ds-clear-btn" id="ds-clear-full">✕ Clear</button></div>
    </div>
    <div class="ds-toggle"><input type="checkbox" id="ds-full-on"><label for="ds-full-on">Enable</label></div>
    <div class="ds-row"><label>Size</label><input type="range" id="ds-full-size" min="10" max="160" step="1"><span class="ds-val" id="ds-full-size-v">80px</span></div>
    <div class="ds-row"><label>Opacity</label><input type="range" id="ds-full-opacity" min="0.1" max="1" step="0.01"><span class="ds-val" id="ds-full-opacity-v">100%</span></div>
    <div class="ds-toggle"><input type="checkbox" id="ds-full-spin"><label for="ds-full-spin">Spin</label></div>
    <div class="ds-row"><label>Spin speed</label><input type="range" id="ds-full-spin-spd" min="0.1" max="10" step="0.1"><span class="ds-val" id="ds-full-spin-spd-v">1</span></div>

    <div class="ds-section">Mode 2 — Custom Dot</div>
    <div class="ds-img-row">
      <img class="ds-img-preview" id="ds-prev-dot">
      <div style="flex:1"><label class="ds-upload-btn" for="ds-upload-dot">📁 Upload</label><input type="file" id="ds-upload-dot" accept="image/*" style="display:none"><button class="ds-clear-btn" id="ds-clear-dot">✕ Clear</button></div>
    </div>
    <div class="ds-toggle"><input type="checkbox" id="ds-dot-img-on"><label for="ds-dot-img-on">Enable</label></div>
    <div class="ds-row"><label>Size</label><input type="range" id="ds-dot-img-size" min="4" max="60" step="1"><span class="ds-val" id="ds-dot-img-size-v">10px</span></div>
    <div class="ds-toggle"><input type="checkbox" id="ds-dot-img-spin"><label for="ds-dot-img-spin">Spin</label></div>
    <div class="ds-row"><label>Spin speed</label><input type="range" id="ds-dot-img-spd" min="0.1" max="10" step="0.1"><span class="ds-val" id="ds-dot-img-spd-v">2</span></div>

    <div class="ds-section">Mode 3 — Custom Arms</div>
    <div class="ds-img-row">
      <img class="ds-img-preview" id="ds-prev-arm">
      <div style="flex:1"><label class="ds-upload-btn" for="ds-upload-arm">📁 Upload</label><input type="file" id="ds-upload-arm" accept="image/*" style="display:none"><button class="ds-clear-btn" id="ds-clear-arm">✕ Clear</button></div>
    </div>
    <div class="ds-toggle"><input type="checkbox" id="ds-arm-on"><label for="ds-arm-on">Enable</label></div>
    <div class="ds-row"><label>Tile size</label><input type="range" id="ds-arm-size" min="2" max="30" step="1"><span class="ds-val" id="ds-arm-size-v">8px</span></div>
    <div class="ds-row"><label>Spacing</label><input type="range" id="ds-arm-spacing" min="0" max="20" step="1"><span class="ds-val" id="ds-arm-spacing-v">2px</span></div>

    <div class="ds-section">Mode 4 — Orbit / Border</div>
    <div class="ds-img-row">
      <img class="ds-img-preview" id="ds-prev-orbit">
      <div style="flex:1"><label class="ds-upload-btn" for="ds-upload-orbit">📁 Upload</label><input type="file" id="ds-upload-orbit" accept="image/*" style="display:none"><button class="ds-clear-btn" id="ds-clear-orbit">✕ Clear</button></div>
    </div>
    <div class="ds-toggle"><input type="checkbox" id="ds-orbit-on"><label for="ds-orbit-on">Enable</label></div>
    <div class="ds-row"><label>Mode</label>
      <select id="ds-orbit-mode">
        <option value="repeat">Repeating (border of images)</option>
        <option value="single">Single image</option>
      </select>
    </div>
    <div id="ds-orbit-repeat-opts">
      <div class="ds-row"><label>Count</label><input type="range" id="ds-orbit-count" min="1" max="24" step="1"><span class="ds-val" id="ds-orbit-count-v">8</span></div>
      <div class="ds-row"><label>Icon size</label><input type="range" id="ds-orbit-size" min="4" max="40" step="1"><span class="ds-val" id="ds-orbit-size-v">12px</span></div>
    </div>
    <div id="ds-orbit-single-opts">
      <div class="ds-row"><label>Destination</label>
        <select id="ds-orbit-dest">
          <option value="orbit">Travel orbit path</option>
          <option value="center">Stay at center</option>
        </select>
      </div>
      <div class="ds-row"><label>Size</label><input type="range" id="ds-orbit-single-size" min="10" max="160" step="1"><span class="ds-val" id="ds-orbit-single-size-v">60px</span></div>
    </div>
    <div class="ds-row"><label>Shape</label>
      <select id="ds-orbit-shape">
        <option value="circle">Circle</option>
        <option value="oval">Oval</option>
        <option value="square">Square path</option>
      </select>
    </div>
    <div class="ds-row"><label>Radius</label><input type="range" id="ds-orbit-radius" min="10" max="80" step="1"><span class="ds-val" id="ds-orbit-radius-v">30px</span></div>
    <div class="ds-toggle"><input type="checkbox" id="ds-orbit-spin"><label for="ds-orbit-spin">Orbit / travel around path</label></div>
    <div class="ds-row"><label>Speed</label><input type="range" id="ds-orbit-spd" min="0.1" max="10" step="0.1"><span class="ds-val" id="ds-orbit-spd-v">1</span></div>
    <div class="ds-toggle"><input type="checkbox" id="ds-orbit-self-spin"><label for="ds-orbit-self-spin">Self-spin on own axis</label></div>
    <div class="ds-foot"><button class="ds-btn ds-btn-save" id="ds-save-images">Save</button></div>
  `);

  makePanel('presets','Presets','Press K to toggle — save up to 5 slots. Export/import as a code.',`
    <div class="ds-section">Slots</div>
    <div class="ds-preset-grid" id="ds-preset-grid"></div>
    <div class="ds-row" style="margin-top:4px;">
      <button class="ds-btn ds-btn-save" id="ds-preset-save-cur" style="font-size:11px;">Save to selected slot</button>
    </div>
    <div class="ds-section">Share</div>
    <p style="font-size:11px;color:#666;margin:0 0 8px;">Export your current settings as a code to share. Paste someone else's code to import.</p>
    <div class="ds-row"><input type="text" id="ds-preset-code" placeholder="Paste code here or export below" style="font-size:10px;"></div>
    <div class="ds-foot">
      <button class="ds-btn ds-btn-save" id="ds-preset-export">Export code</button>
      <button class="ds-btn ds-btn-reset" id="ds-preset-import">Import code</button>
    </div>
    <div id="ds-preset-msg" style="font-size:11px;color:#00ff88;margin-top:8px;min-height:14px;"></div>
  `);

  makePanel('overlays','HUD Overlays','Press ` to toggle',`
    <div class="ds-section">Visibility</div>
    <div class="ds-toggle"><input type="checkbox" id="ds-fps"><label for="ds-fps">Live FPS</label></div>
    <div class="ds-toggle"><input type="checkbox" id="ds-ping"><label for="ds-ping">Live Ping</label></div>
    <div class="ds-toggle"><input type="checkbox" id="ds-keys"><label for="ds-keys">Key Tracker</label></div>
    <div class="ds-section">Overlay Color</div>
    <div class="ds-row"><label>Color</label><input type="color" id="ds-overlay-color"><input type="text" id="ds-overlay-color-hex" maxlength="7" placeholder="#00ff88"></div>
    <div class="ds-section">Preview Box</div>
    <div class="ds-toggle"><input type="checkbox" id="ds-show-preview"><label for="ds-show-preview">Show preview box</label></div>
    <div class="ds-foot"><button class="ds-btn ds-btn-save" id="ds-save-overlays">Save</button></div>
  `);

  // ─── PRESETS LOGIC ────────────────────────────────────────────────────────────
  let selectedPresetSlot = 0;

  function buildPresetGrid() {
    const grid=document.getElementById('ds-preset-grid');
    if(!grid) return;
    grid.innerHTML='';
    for(let i=0;i<5;i++){
      const btn=document.createElement('div');
      btn.className='ds-preset-btn'+(PRESETS[i]?' filled':'')+(i===selectedPresetSlot?' active':'');
      btn.style.outline=i===selectedPresetSlot?'2px solid #00ff88':'';
      btn.textContent=PRESETS[i]?`Slot ${i+1}`:`Empty`;
      btn.style.fontSize='10px';
      btn.addEventListener('click',()=>{
        selectedPresetSlot=i;
        buildPresetGrid();
        if(PRESETS[i]){ Object.assign(S,PRESETS[i]); save(); populate(); scheduleRedraw(); updateOverlays(); prevWrap.style.display=S.showPreview?'flex':'none'; }
      });
      grid.appendChild(btn);
    }
  }

  function presetMsg(txt,ok=true){ const el=document.getElementById('ds-preset-msg'); if(el){ el.textContent=txt; el.style.color=ok?'#00ff88':'#ff4444'; setTimeout(()=>el.textContent='',2500); } }

  document.addEventListener('click', e=>{
    if(e.target.id==='ds-preset-save-cur'){
      PRESETS[selectedPresetSlot]=Object.assign({},S);
      savePresets(); buildPresetGrid(); presetMsg(`Saved to slot ${selectedPresetSlot+1}`);
    }
    if(e.target.id==='ds-preset-export'){
      const code=btoa(JSON.stringify(S));
      document.getElementById('ds-preset-code').value=code;
      navigator.clipboard.writeText(code).catch(()=>{});
      presetMsg('Code copied to clipboard!');
    }
    if(e.target.id==='ds-preset-import'){
      try{
        const code=document.getElementById('ds-preset-code').value.trim();
        const imported=JSON.parse(atob(code));
        Object.assign(S,imported); save(); populate(); scheduleRedraw(); updateOverlays();
        prevWrap.style.display=S.showPreview?'flex':'none';
        presetMsg('Imported!');
      }catch(e){ presetMsg('Invalid code.',false); }
    }
  });

  // orbit mode show/hide options
  function updateOrbitOpts(){
    const mode=document.getElementById('ds-orbit-mode');
    if(!mode) return;
    const repeat=document.getElementById('ds-orbit-repeat-opts');
    const single=document.getElementById('ds-orbit-single-opts');
    if(mode.value==='single'){ if(repeat) repeat.style.display='none'; if(single) single.style.display=''; }
    else { if(repeat) repeat.style.display=''; if(single) single.style.display='none'; }
  }

  // ─── IMAGE UPLOAD WIRING ──────────────────────────────────────────────────────
  function wireUpload(inputId,slot,previewId){
    const inp=document.getElementById(inputId);
    if(!inp) return;
    inp.addEventListener('change',async function(){
      const file=this.files[0]; if(!file) return;
      const reader=new FileReader();
      reader.onload=async e=>{
        IMG[slot]=e.target.result; saveImgs();
        await decodeBitmap(slot);
        const prev=document.getElementById(previewId);
        if(prev){ prev.src=IMG[slot]; prev.classList.add('has-img'); }
        scheduleRedraw();
      };
      reader.readAsDataURL(file);
    });
    const clr=document.getElementById('ds-clear-'+slot);
    if(clr) clr.addEventListener('click',async()=>{
      IMG[slot]=null; saveImgs(); BMP[slot]=null;
      const prev=document.getElementById(previewId);
      if(prev){ prev.src=''; prev.classList.remove('has-img'); }
      scheduleRedraw();
    });
  }
  wireUpload('ds-upload-full','full','ds-prev-full');
  wireUpload('ds-upload-dot','dot','ds-prev-dot');
  wireUpload('ds-upload-arm','arm','ds-prev-arm');
  wireUpload('ds-upload-orbit','orbit','ds-prev-orbit');

  function populateImagePreviews(){
    [['full','ds-prev-full'],['dot','ds-prev-dot'],['arm','ds-prev-arm'],['orbit','ds-prev-orbit']].forEach(([slot,id])=>{
      const el=document.getElementById(id);
      if(el&&IMG[slot]){ el.src=IMG[slot]; el.classList.add('has-img'); }
      else if(el){ el.src=''; el.classList.remove('has-img'); }
    });
  }

  // ─── POPULATE & READ ──────────────────────────────────────────────────────────
  function g(id){ return document.getElementById(id); }

  function populate(){
    if(!g('ds-master')) return;
    g('ds-master').checked             = S.masterShow;
    g('ds-style').value                = S.style;
    g('ds-spin').checked               = S.xhairSpin;
    g('ds-spin-spd').value             = S.xhairSpinSpd;
    g('ds-spin-spd-v').textContent     = S.xhairSpinSpd;
    g('ds-breathe').checked            = S.xhairBreathe;
    g('ds-breathe-spd').value          = S.xhairBreatheSpd;
    g('ds-breathe-spd-v').textContent  = S.xhairBreatheSpd;
    g('ds-breathe-amt').value          = S.xhairBreatheAmt;
    g('ds-breathe-amt-v').textContent  = S.xhairBreatheAmt+'px';
    g('ds-psycho').checked             = S.psychedelic;
    g('ds-psycho-speed').value         = S.psychoSpeed;
    g('ds-psycho-speed-v').textContent = S.psychoSpeed;
    g('ds-color').value                = S.color;
    g('ds-color-hex').value            = S.color;
    g('ds-outline-color').value        = S.outlineColor;
    g('ds-outline-hex').value          = S.outlineColor;
    g('ds-opacity').value              = S.opacity;
    g('ds-opacity-v').textContent      = Math.round(S.opacity*100)+'%';
    g('ds-hit-on').checked             = S.hitMarker;
    g('ds-hit-color').value            = S.hitColor;
    g('ds-hit-hex').value              = S.hitColor;
    g('ds-hit-size').value             = S.hitSize;
    g('ds-hit-size-v').textContent     = S.hitSize+'px';
    g('ds-hit-thick').value            = S.hitThick;
    g('ds-hit-thick-v').textContent    = S.hitThick+'px';
    g('ds-hit-dur').value              = S.hitDuration;
    g('ds-hit-dur-v').textContent      = S.hitDuration+'ms';
    g('ds-outline').checked            = S.showOutline;
    g('ds-dot-type').value             = S.dotType;
    g('ds-dot-size').value             = S.dotSize;
    g('ds-dot-size-v').textContent     = S.dotSize+'px';
    g('ds-circle-r').value             = S.circleRadius;
    g('ds-circle-r-v').textContent     = S.circleRadius+'px';
    // Arms toggle buttons
    const armMap = {top:S.showTop, right:S.showRight, left:S.showLeft, bottom:S.showBottom};
    ['top','right','left','bottom'].forEach(arm=>{
      const el=document.getElementById('arm-'+arm);
      if(!el) return;
      if(armMap[arm]) el.classList.add('on');
      else el.classList.remove('on');
    });
    g('ds-len').value                  = S.len;
    g('ds-len-v').textContent          = S.len+'px';
    g('ds-thick').value                = S.thick;
    g('ds-thick-v').textContent        = S.thick+'px';
    g('ds-gap').value                  = S.gap;
    g('ds-gap-v').textContent          = S.gap+'px';
    g('ds-fps').checked                = S.showFPS;
    g('ds-ping').checked               = S.showPing;
    g('ds-keys').checked               = S.showKeys;
    g('ds-overlay-color').value        = S.overlayColor;
    g('ds-overlay-color-hex').value    = S.overlayColor;
    g('ds-show-preview').checked       = S.showPreview;
    // Image
    g('ds-full-on').checked            = S.img_full_on;
    g('ds-full-size').value            = S.img_full_size;
    g('ds-full-size-v').textContent    = S.img_full_size+'px';
    g('ds-full-opacity').value         = S.img_full_opacity;
    g('ds-full-opacity-v').textContent = Math.round(S.img_full_opacity*100)+'%';
    g('ds-full-spin').checked          = S.img_full_spin;
    g('ds-full-spin-spd').value        = S.img_full_spinSpd;
    g('ds-full-spin-spd-v').textContent= S.img_full_spinSpd;
    g('ds-dot-img-on').checked         = S.img_dot_on;
    g('ds-dot-img-size').value         = S.img_dot_size;
    g('ds-dot-img-size-v').textContent = S.img_dot_size+'px';
    g('ds-dot-img-spin').checked       = S.img_dot_spin;
    g('ds-dot-img-spd').value          = S.img_dot_spinSpd;
    g('ds-dot-img-spd-v').textContent  = S.img_dot_spinSpd;
    g('ds-arm-on').checked             = S.img_arm_on;
    g('ds-arm-size').value             = S.img_arm_size;
    g('ds-arm-size-v').textContent     = S.img_arm_size+'px';
    g('ds-arm-spacing').value          = S.img_arm_spacing;
    g('ds-arm-spacing-v').textContent  = S.img_arm_spacing+'px';
    g('ds-orbit-on').checked           = S.img_orbit_on;
    g('ds-orbit-mode').value           = S.img_orbit_mode;
    g('ds-orbit-count').value          = S.img_orbit_count;
    g('ds-orbit-count-v').textContent  = S.img_orbit_count;
    g('ds-orbit-size').value           = S.img_orbit_size;
    g('ds-orbit-size-v').textContent   = S.img_orbit_size+'px';
    g('ds-orbit-dest').value           = S.img_orbit_singleDest;
    g('ds-orbit-single-size').value    = S.img_orbit_singleSize;
    g('ds-orbit-single-size-v').textContent = S.img_orbit_singleSize+'px';
    g('ds-orbit-shape').value          = S.img_orbit_shape;
    g('ds-orbit-radius').value         = S.img_orbit_radius;
    g('ds-orbit-radius-v').textContent = S.img_orbit_radius+'px';
    g('ds-orbit-spin').checked         = S.img_orbit_spin;
    g('ds-orbit-spd').value            = S.img_orbit_spinSpd;
    g('ds-orbit-spd-v').textContent    = S.img_orbit_spinSpd;
    g('ds-orbit-self-spin').checked    = S.img_orbit_selfSpin;
    updateOrbitOpts();
    populateImagePreviews();
    buildPresetGrid();
  }

  function readAll(){
    S.masterShow      = g('ds-master').checked;
    S.style           = g('ds-style').value;
    S.xhairSpin       = g('ds-spin').checked;
    S.xhairSpinSpd    = parseFloat(g('ds-spin-spd').value);
    S.xhairBreathe    = g('ds-breathe').checked;
    S.xhairBreatheSpd = parseFloat(g('ds-breathe-spd').value);
    S.xhairBreatheAmt = parseInt(g('ds-breathe-amt').value);
    S.psychedelic     = g('ds-psycho').checked;
    S.psychoSpeed     = parseInt(g('ds-psycho-speed').value);
    if(!S.psychedelic){ S.color=g('ds-color').value; S.outlineColor=g('ds-outline-color').value; S.overlayColor=g('ds-overlay-color').value; }
    S.opacity         = parseFloat(g('ds-opacity').value);
    S.hitMarker       = g('ds-hit-on').checked;
    S.hitColor        = g('ds-hit-color').value;
    S.hitSize         = parseInt(g('ds-hit-size').value);
    S.hitThick        = parseInt(g('ds-hit-thick').value);
    S.hitDuration     = parseInt(g('ds-hit-dur').value);
    S.showOutline     = g('ds-outline').checked;
    S.dotType         = g('ds-dot-type').value;
    S.dotSize         = parseInt(g('ds-dot-size').value);
    S.circleRadius    = parseInt(g('ds-circle-r').value);
    S.len             = parseInt(g('ds-len').value);
    S.thick           = parseInt(g('ds-thick').value);
    S.gap             = parseInt(g('ds-gap').value);
    // Read arm toggle buttons directly (they manage their own state via __dsArmChange)
    const armTopEl=document.getElementById('arm-top');
    if(armTopEl){ S.showTop=armTopEl.classList.contains('on'); S.showRight=document.getElementById('arm-right').classList.contains('on'); S.showLeft=document.getElementById('arm-left').classList.contains('on'); S.showBottom=document.getElementById('arm-bottom').classList.contains('on'); }
    S.showFPS         = g('ds-fps').checked;
    S.showPing        = g('ds-ping').checked;
    S.showKeys        = g('ds-keys').checked;
    S.showPreview     = g('ds-show-preview').checked;
    S.img_full_on     = g('ds-full-on').checked;
    S.img_full_size   = parseInt(g('ds-full-size').value);
    S.img_full_opacity= parseFloat(g('ds-full-opacity').value);
    S.img_full_spin   = g('ds-full-spin').checked;
    S.img_full_spinSpd= parseFloat(g('ds-full-spin-spd').value);
    S.img_dot_on      = g('ds-dot-img-on').checked;
    S.img_dot_size    = parseInt(g('ds-dot-img-size').value);
    S.img_dot_spin    = g('ds-dot-img-spin').checked;
    S.img_dot_spinSpd = parseFloat(g('ds-dot-img-spd').value);
    S.img_arm_on      = g('ds-arm-on').checked;
    S.img_arm_size    = parseInt(g('ds-arm-size').value);
    S.img_arm_spacing = parseInt(g('ds-arm-spacing').value);
    S.img_orbit_on    = g('ds-orbit-on').checked;
    S.img_orbit_mode  = g('ds-orbit-mode').value;
    S.img_orbit_count = parseInt(g('ds-orbit-count').value);
    S.img_orbit_size  = parseInt(g('ds-orbit-size').value);
    S.img_orbit_singleDest = g('ds-orbit-dest').value;
    S.img_orbit_singleSize = parseInt(g('ds-orbit-single-size').value);
    S.img_orbit_shape = g('ds-orbit-shape').value;
    S.img_orbit_radius= parseInt(g('ds-orbit-radius').value);
    S.img_orbit_spin  = g('ds-orbit-spin').checked;
    S.img_orbit_spinSpd=parseFloat(g('ds-orbit-spd').value);
    S.img_orbit_selfSpin=g('ds-orbit-self-spin').checked;

    // Update displayed values
    g('ds-spin-spd-v').textContent      = S.xhairSpinSpd;
    g('ds-breathe-spd-v').textContent   = S.xhairBreatheSpd;
    g('ds-breathe-amt-v').textContent   = S.xhairBreatheAmt+'px';
    g('ds-psycho-speed-v').textContent  = S.psychoSpeed;
    g('ds-opacity-v').textContent       = Math.round(S.opacity*100)+'%';
    g('ds-hit-size-v').textContent      = S.hitSize+'px';
    g('ds-hit-thick-v').textContent     = S.hitThick+'px';
    g('ds-hit-dur-v').textContent       = S.hitDuration+'ms';
    g('ds-dot-size-v').textContent      = S.dotSize+'px';
    g('ds-circle-r-v').textContent      = S.circleRadius+'px';
    g('ds-len-v').textContent           = S.len+'px';
    g('ds-thick-v').textContent         = S.thick+'px';
    g('ds-gap-v').textContent           = S.gap+'px';
    g('ds-full-size-v').textContent     = S.img_full_size+'px';
    g('ds-full-opacity-v').textContent  = Math.round(S.img_full_opacity*100)+'%';
    g('ds-full-spin-spd-v').textContent = S.img_full_spinSpd;
    g('ds-dot-img-size-v').textContent  = S.img_dot_size+'px';
    g('ds-dot-img-spd-v').textContent   = S.img_dot_spinSpd;
    g('ds-arm-size-v').textContent      = S.img_arm_size+'px';
    g('ds-arm-spacing-v').textContent   = S.img_arm_spacing+'px';
    g('ds-orbit-count-v').textContent   = S.img_orbit_count;
    g('ds-orbit-size-v').textContent    = S.img_orbit_size+'px';
    g('ds-orbit-single-size-v').textContent = S.img_orbit_singleSize+'px';
    g('ds-orbit-radius-v').textContent  = S.img_orbit_radius+'px';
    g('ds-orbit-spd-v').textContent     = S.img_orbit_spinSpd;

    updateOrbitOpts();
    if(S.psychedelic&&!psychoInterval) startPsycho();
    else if(!S.psychedelic&&psychoInterval) stopPsycho();
    if(S.psychedelic) document.documentElement.style.setProperty('--ds-psycho-dur',getPsychoDur());

    prevWrap.style.display=S.showPreview?'flex':'none';
    updateOverlays();
    scheduleRedraw();
  }

  // Color sync
  [['ds-color','ds-color-hex'],['ds-outline-color','ds-outline-hex'],
   ['ds-hit-color','ds-hit-hex'],['ds-overlay-color','ds-overlay-color-hex']].forEach(([pick,hex])=>{
    const p=g(pick),h=g(hex); if(!p||!h) return;
    p.addEventListener('input',e=>{ h.value=e.target.value; readAll(); });
    h.addEventListener('input',e=>{ if(/^#[0-9a-fA-F]{6}$/.test(e.target.value)){ p.value=e.target.value; readAll(); } });
  });

  // Wire all inputs
  ['ds-master','ds-style','ds-spin','ds-spin-spd','ds-breathe','ds-breathe-spd','ds-breathe-amt',
   'ds-psycho','ds-psycho-speed','ds-opacity',
   'ds-hit-on','ds-hit-size','ds-hit-thick','ds-hit-dur',
   'ds-outline','ds-dot-type','ds-dot-size','ds-circle-r',
   'ds-len','ds-thick','ds-gap','ds-fps','ds-ping','ds-keys','ds-show-preview',
   'ds-full-on','ds-full-size','ds-full-opacity','ds-full-spin','ds-full-spin-spd',
   'ds-dot-img-on','ds-dot-img-size','ds-dot-img-spin','ds-dot-img-spd',
   'ds-arm-on','ds-arm-size','ds-arm-spacing',
   'ds-orbit-on','ds-orbit-mode','ds-orbit-count','ds-orbit-size',
   'ds-orbit-dest','ds-orbit-single-size',
   'ds-orbit-shape','ds-orbit-radius','ds-orbit-spin','ds-orbit-spd','ds-orbit-self-spin',
  ].forEach(id=>{ const el=g(id); if(!el) return; el.addEventListener('input',readAll); el.addEventListener('change',readAll); });

  // Save buttons
  ['style','colors','details','arms','dims','images','overlays'].forEach(id=>{
    const btn=g('ds-save-'+id);
    if(btn) btn.addEventListener('click',()=>{ save(); btn.textContent='Saved!'; setTimeout(()=>btn.textContent='Save',1500); });
  });

  g('ds-reset-all').addEventListener('click',()=>{
    S=Object.assign({},defaults); stopPsycho(); save();
    populate(); scheduleRedraw(); updateOverlays();
    prevWrap.style.display=S.showPreview?'flex':'none';
  });

  // ─── PANEL TOGGLE ─────────────────────────────────────────────────────────────
  const panelMap={style:'ds-panel-style',colors:'ds-panel-colors',details:'ds-panel-details',arms:'ds-panel-arms',dims:'ds-panel-dims',images:'ds-panel-images',presets:'ds-panel-presets',overlays:'ds-panel-overlays'};
  let openPanel=null;

  function togglePanel(name){
    const panelEl=g(panelMap[name]);
    const btnEl=sidebar.querySelector('[data-panel="'+name+'"]');
    if(openPanel&&openPanel!==name){ g(panelMap[openPanel]).classList.remove('open'); sidebar.querySelector('[data-panel="'+openPanel+'"]').classList.remove('active'); }
    if(openPanel===name){ panelEl.classList.remove('open'); btnEl.classList.remove('active'); openPanel=null; }
    else{ populate(); panelEl.classList.add('open'); btnEl.classList.add('active'); openPanel=name; }
  }

  sidebar.querySelectorAll('.ds-sbb').forEach(btn=>btn.addEventListener('click',()=>togglePanel(btn.dataset.panel)));

  document.addEventListener('keydown',e=>{
    if(e.target.tagName==='INPUT'&&e.target.type==='text') return;
    const k=e.key;
    if(k==='u'||k==='U')       sidebar.classList.toggle('hidden-sidebar');
    else if(k==='\\')           togglePanel('style');
    else if(k==='o'||k==='O')  togglePanel('colors');
    else if(k==='.')            togglePanel('details');
    else if(k==='i'||k==='I')  togglePanel('arms');
    else if(k==='/')            { e.preventDefault(); togglePanel('dims'); }
    else if(k==='p'||k==='P')  togglePanel('images');
    else if(k==='k'||k==='K')  togglePanel('presets');
    else if(k==='`')            togglePanel('overlays');
    else if(['1','2','3','4','5'].includes(k)){
      const idx=parseInt(k)-1;
      if(PRESETS[idx]){ Object.assign(S,PRESETS[idx]); save(); populate(); scheduleRedraw(); updateOverlays(); prevWrap.style.display=S.showPreview?'flex':'none'; buildPresetGrid(); }
    }
  });

  // ─── DRAGGABLE PANELS ─────────────────────────────────────────────────────────
  document.querySelectorAll('.ds-panel').forEach(p=>{
    let drag=false,ox=0,oy=0;
    p.addEventListener('mousedown',e=>{ if(['INPUT','SELECT','BUTTON','LABEL'].includes(e.target.tagName)) return; drag=true; const r=p.getBoundingClientRect(); ox=e.clientX-r.left; oy=e.clientY-r.top; p.style.cursor='grabbing'; e.preventDefault(); });
    document.addEventListener('mousemove',e=>{ if(!drag) return; p.style.left=(e.clientX-ox)+'px'; p.style.top=(e.clientY-oy)+'px'; p.style.right='auto'; p.style.transform='none'; });
    document.addEventListener('mouseup',()=>{ drag=false; p.style.cursor=''; });
  });

  // ─── INIT ─────────────────────────────────────────────────────────────────────
  if(!S.sidebarVisible) sidebar.classList.add('hidden-sidebar');
  prevWrap.style.display=S.showPreview?'flex':'none';
  updateOverlays();
  decodeAll().then(()=>{ populate(); scheduleRedraw(); if(S.psychedelic) startPsycho(); });

})();
