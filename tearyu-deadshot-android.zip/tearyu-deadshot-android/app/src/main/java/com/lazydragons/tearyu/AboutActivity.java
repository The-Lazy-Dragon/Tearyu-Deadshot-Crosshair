package com.lazydragons.tearyu;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.card.MaterialCardView;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        // GitHub profile
        findViewById(R.id.link_github_profile).setOnClickListener(v ->
            openUrl("https://github.com/The-Lazy-Dragon"));

        // Crosshair repo card
        findViewById(R.id.card_crosshair_repo).setOnClickListener(v ->
            openUrl("https://github.com/The-Lazy-Dragon/tearyu-deadshot-crosshair"));

        // NavalStrike
        findViewById(R.id.link_naval).setOnClickListener(v ->
            openUrl("https://github.com/The-Lazy-Dragon/NavalStrike"));
        findViewById(R.id.card_naval).setOnClickListener(v ->
            openUrl("https://github.com/The-Lazy-Dragon/NavalStrike"));

        // TicTacToe
        findViewById(R.id.link_tictactoe).setOnClickListener(v ->
            openUrl("https://github.com/The-Lazy-Dragon/lazy-dragons-tictactoe"));
        findViewById(R.id.card_tictactoe).setOnClickListener(v ->
            openUrl("https://github.com/The-Lazy-Dragon/lazy-dragons-tictactoe"));
    }

    private void openUrl(String url) {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }
}
