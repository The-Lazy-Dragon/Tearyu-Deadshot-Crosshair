package com.lazydragons.tearyu;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private MaterialButton btnToggleCrosshair;
    private MaterialButton btnOpenSettings;
    private MaterialButton btnAbout;
    private LinearLayout notDeadshotWarning;
    private boolean crosshairEnabled = false;
    private String crosshairJS = "";
    private static final String DEADSHOT_URL = "https://deadshot.io";
    private static final int OVERLAY_PERMISSION_REQUEST = 1001;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView           = findViewById(R.id.webview);
        btnToggleCrosshair= findViewById(R.id.btn_toggle_crosshair);
        btnOpenSettings   = findViewById(R.id.btn_open_settings);
        btnAbout          = findViewById(R.id.btn_about);
        notDeadshotWarning= findViewById(R.id.not_deadshot_warning);
        MaterialButton btnGoDeadshot = findViewById(R.id.btn_go_deadshot);

        // Load crosshair JS from raw resource
        crosshairJS = loadRawResource(R.raw.crosshair);

        // WebView setup
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        );

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                boolean isDeadshot = url != null && url.contains("deadshot.io");
                webView.setVisibility(isDeadshot ? View.VISIBLE : View.GONE);
                notDeadshotWarning.setVisibility(isDeadshot ? View.GONE : View.VISIBLE);

                if (isDeadshot && crosshairEnabled) {
                    injectCrosshair();
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // Keep all navigation inside the WebView
                return false;
            }
        });

        webView.loadUrl(DEADSHOT_URL);

        // Buttons
        btnToggleCrosshair.setOnClickListener(v -> toggleCrosshair());
        btnOpenSettings.setOnClickListener(v -> openCrosshairSettings());
        btnAbout.setOnClickListener(v -> startActivity(new Intent(this, AboutActivity.class)));
        btnGoDeadshot.setOnClickListener(v -> {
            notDeadshotWarning.setVisibility(View.GONE);
            webView.setVisibility(View.VISIBLE);
            webView.loadUrl(DEADSHOT_URL);
        });

        // Check overlay permission on launch
        checkOverlayPermission();
    }

    private void toggleCrosshair() {
        crosshairEnabled = !crosshairEnabled;
        if (crosshairEnabled) {
            btnToggleCrosshair.setText("⊕  Crosshair ON");
            btnToggleCrosshair.setBackgroundTintList(
                getColorStateList(R.color.accent)
            );
            injectCrosshair();
        } else {
            btnToggleCrosshair.setText("⊕  Crosshair OFF");
            btnToggleCrosshair.setBackgroundTintList(
                getColorStateList(R.color.bg_card)
            );
            removeCrosshair();
        }
    }

    private void injectCrosshair() {
        if (crosshairJS.isEmpty()) return;
        // Escape backticks and wrap in a function to avoid double-injection
        String escaped = crosshairJS
            .replace("\\", "\\\\")
            .replace("`", "\\`")
            .replace("$", "\\$");
        // Use evaluateJavascript for safe injection
        webView.evaluateJavascript(crosshairJS, null);
    }

    private void removeCrosshair() {
        // Remove the canvas and all injected elements, reset guard
        webView.evaluateJavascript(
            "(function(){" +
            "  window.__ds_xhair_v6 = false;" +
            "  var cv = document.querySelector('canvas[style*=\"999998\"]');" +
            "  if (cv) cv.remove();" +
            "  var sidebar = document.getElementById('ds-sidebar');" +
            "  if (sidebar) sidebar.remove();" +
            "  document.querySelectorAll('.ds-panel, #ds-preview-wrap, #ds-overlay-root').forEach(function(el){el.remove();});" +
            "})()",
            null
        );
    }

    private void openCrosshairSettings() {
        // Toggle the style panel open via JS keyboard simulation
        webView.evaluateJavascript(
            "(function(){" +
            "  var sidebar = document.getElementById('ds-sidebar');" +
            "  if (!sidebar) return;" +
            "  sidebar.classList.remove('hidden-sidebar');" +
            "  var btn = sidebar.querySelector('[data-panel=\"style\"]');" +
            "  if (btn) btn.click();" +
            "})()",
            null
        );
    }

    private void checkOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this)
                .setTitle("Overlay Permission Needed")
                .setMessage(
                    "This app needs permission to draw over other apps to show your " +
                    "crosshair while you play deadshot.io.\n\nTap OK to open Settings " +
                    "and enable 'Appear on top' for this app."
                )
                .setPositiveButton("OK", (dialog, which) -> {
                    Intent intent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                    );
                    startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST);
                })
                .setNegativeButton("Skip", null)
                .show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_PERMISSION_REQUEST) {
            if (!Settings.canDrawOverlays(this)) {
                // Permission denied — inform user the crosshair still works inside the app
                new AlertDialog.Builder(this)
                    .setTitle("No problem")
                    .setMessage(
                        "The crosshair will still work inside this app while you play. " +
                        "You only need the overlay permission if you want to use other apps " +
                        "simultaneously while the crosshair is visible."
                    )
                    .setPositiveButton("Got it", null)
                    .show();
            }
        }
    }

    private String loadRawResource(int resId) {
        try {
            BufferedReader reader = new BufferedReader(
                new InputStreamReader(getResources().openRawResource(resId))
            );
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            reader.close();
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }
}
