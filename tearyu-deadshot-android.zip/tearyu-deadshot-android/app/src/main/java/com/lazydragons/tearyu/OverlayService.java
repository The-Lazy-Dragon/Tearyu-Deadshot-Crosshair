package com.lazydragons.tearyu;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

// Placeholder for future system-level overlay service
// Currently the crosshair runs inside the WebView — no system overlay needed
public class OverlayService extends Service {
    @Override
    public IBinder onBind(Intent intent) { return null; }
}
